<?php return array (
  'data-table' => 'App\\Http\\Livewire\\DataTable',
  'sidebar-menu' => 'App\\Http\\Livewire\\SidebarMenu',
  'system-configuration' => 'App\\Http\\Livewire\\SystemConfiguration',
  'system-module-task' => 'App\\Http\\Livewire\\SystemModuleTask',
  'user-group' => 'App\\Http\\Livewire\\UserGroup',
  'users-admin' => 'App\\Http\\Livewire\\UsersAdmin',
);