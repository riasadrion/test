<?php
namespace App\HelperClasses;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class QueryHelper
{
    public static function add($table_name, $data, $controllerClass = '', $save_history = true)
    {
        $id = DB::table($table_name)->insertGetId($data);
        if ($id && ($id > 0)) {
            if ($save_history) {
                $history_data = [
                    'controller' => $controllerClass,
                    'table_id' => $id,
                    'table_name' => $table_name,
                    'data' => json_encode($data),
                    'user_id' => Auth::id(),
                    'action' => 'INSERT'
                ];
                return self::save_history($history_data);
            }
            return $id;
        } else {
            return false;
        }
    }

    public static function update($table_name, $data, $conditions, $controllerClass = '', $save_history = true)
    {
        // First: FETCH all the existing records
        $query = DB::table($table_name);
        foreach ($conditions as $field => $value) {
            $query->where($field, $value);
        }
        $rows = $query->get();

        // Second: UPDATE all the existing records
        $query = DB::table($table_name);
        foreach ($conditions as $field => $value) {
            $query->where($field, $value);
        }
        $affected_rows = $query->update($data);

        if ($affected_rows && ($affected_rows > 0)) {
            // Finally: SAVE all the records in History table
            if ($save_history) {
                foreach ($rows as $row) {
                    $history_data = [
                        'controller' => $controllerClass,
                        'table_id' => $row->id,
                        'table_name' => $table_name,
                        'data' => json_encode($data),
                        'user_id' => Auth::id(),
                        'action' => 'UPDATE'
                    ];
                    return self::save_history($history_data);
                }
            }
            return true;
        } else {
            return false;
        }
    }

    public static function save_history($data, $table_history = 'system_history')
    {
        $id = DB::table($table_history)->insertGetId($data);


        /*if ($id && ($id > 0)) {
            return true;
        } else {
            return false;
        }*/
    }
}
