<?php

const STATUS_ACTIVE = 'Active';
const STATUS_INACTIVE = 'In-Active';

const STATUS_YES = 'Yes';
const STATUS_NO = 'No';

const STATUS_MARITAL_MARRIED='Married';
const STATUS_MARITAL_UNMARRIED='Un-Married';

const GENDER_MALE='Male';
const GENDER_FEMALE='Female';

const SYSTEM_MODULE='MODULE';
const SYSTEM_TASK='TASK';
