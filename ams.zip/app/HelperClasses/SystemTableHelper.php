<?php

const TABLE_SYSTEM_TASKS = 'system_tasks';
const TABLE_SYSTEM_CONFIG = 'system_configurations';
const TABLE_USER_GROUP = 'user_groups';
const TABLE_USERS = 'users';
