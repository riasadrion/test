<?php
namespace App\HelperClasses;

use Illuminate\Support\Facades\URL;

class UploadHelper
{

    private $api_url='';

    public static function upload_file($image_temp_url='', $upload_remote=false)
    {
        // URL to get Image from
        $url = URL::to('/').$image_temp_url;

        // URL for upload Image to
        $img = asset('/image/users/u1.jpg');

        echo "=>>> ".$url;
        echo "=>>> ".$img;
        die('56589054');

        file_put_contents($img, file_get_contents($url));

        // Save image
        /*$ch = curl_init($url);
        $fp = fopen($img, 'wb');
        curl_setopt($ch, CURLOPT_FILE, $fp);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_exec($ch);
        curl_close($ch);
        fclose($fp);*/
    }


        /*
        $CI = & get_instance();
        $uploaded_files = array();
        if (sizeof($_FILES) > 0) {
            $file_selected = false;
            $file_size_ok = true;
            foreach ($_FILES as $key => $value) {
                if (strlen($value['name']) > 0) {
                    $file_selected = true;
                    if ($value['size'] > ($max_size * 1000)) {
                        $file_size_ok = false;
                        $uploaded_files[$key] = array('status' => false, 'message' => $value['name'] . ': File size is high');
                    }
                }
            }
            //upload to file server
            if ($file_selected && $file_size_ok) {
                // create curl resource
                $ch = curl_init();
                // set url
                curl_setopt($ch, CURLOPT_URL, $CI->config->item('system_upload_api_url'));

                //set to post data
                curl_setopt($ch, CURLOPT_POST, TRUE);
                $data = array();
                $data['upload_site_root_dir'] = $CI->config->item('system_site_root_folder');
                $data['upload_auth_key'] = $CI->config->item('system_upload_image_auth_key');
                $data['save_dir'] = $save_dir;
                $data['allowed_types'] = $allowed_types;
                $data['max_size'] = $max_size;
                foreach ($_FILES as $key => $value) {
                    if (strlen($value['name']) > 0) {
                        //also check max size here
                        $data[$key] = new CURLFile($value['tmp_name'], $value['type'], $value['name']);
                    }
                }
                curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

                //return the transfer as a string
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

                // $output contains the output string
                $response = curl_exec($ch);
                $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                if ($http_status == 200) {
                    $response_array = json_decode($response, true);
                    if ($response_array['status']) {
                        $uploaded_files = $response_array['uploaded_files'];
                    } else {
                        foreach ($_FILES as $key => $value) {
                            if (strlen($value['name']) > 0) {
                                $uploaded_files[$key] = array('status' => false, 'message' => $response_array['response_message']);
                            }
                        }
                    }
                } else {
                    foreach ($_FILES as $key => $value) {
                        if (strlen($value['name']) > 0) {
                            $uploaded_files[$key] = array('status' => false, 'message' => 'Storage Server Unavailable.<br/>Error Status: ' . $http_status);
                        }
                    }
                }
                // close curl resource to free up system resources
                curl_close($ch);
            }
        }

        return $uploaded_files;
    } */
}
