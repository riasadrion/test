<?php
use \Illuminate\Support\Facades\DB;
use \Illuminate\Support\Facades\Auth;

if (!function_exists('getAuthUser')) {

    function getAuthUser()
    {
        $logged_user_id = Auth::id();
        $result = DB::table(TABLE_USERS)->where('id', $logged_user_id)->select('id', 'name', 'email', 'user_group_id')->first();
        $user = (array)$result;
        if (isset($user['user_group_id']) && $user['user_group_id'] > 0) {
            $user_group = DB::table(TABLE_USER_GROUP)
                                ->where('id', $user['user_group_id'])
                                ->where('status', STATUS_ACTIVE)
                                ->first();

            $user['user_group'] = (array)$user_group;
        }
        return $user;
    }
}

if (!function_exists('getBloodGroups')) {

    function getBloodGroups()
    {
        return [
            'A+',
            'A-',
            'B+',
            'B-',
            'O+',
            'O-',
            'AB+',
            'AB-'
        ];
    }
}
