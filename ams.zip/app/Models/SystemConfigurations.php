<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SystemConfigurations extends Model
{
    protected $table = 'system_configurations';

    use HasFactory;
    protected $guarded = [];
}
