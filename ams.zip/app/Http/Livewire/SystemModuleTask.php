<?php

namespace App\Http\Livewire;

use Illuminate\Support\Facades\DB;
use Livewire\WithPagination;

use App\Models\SystemModuleTasks;
use App\HelperClasses\QueryHelper;

class SystemModuleTask extends RootComponent
{
    public $page_title = 'Module & Task';
    public $task_title;
    public $items;
    public $item;
    public $item_id;

    public $controller_name; // Initialized using constructor

    protected $validationAttributes = [];

    protected $rules = [
        'item.name_en' => 'required|min:3',
        'item.type' => 'required',
        'item.parent' => 'integer',
        'item.ordering' => 'required|integer',
        'item.status' => 'required',
        'item.status_notification' => 'required'
    ];

    public function __construct()
    {
        $class_parts = explode('\\', __CLASS__);
        $this->controller_name = end($class_parts);
        $this->validationAttributes = [
            'item.name_en' => __('tasks.label_task_name_en'),
            'item.type' => __('tasks.label_type'),
            'item.parent' => __('tasks.label_parent'),
            'item.controller' => __('tasks.label_controller'),
            'item.url' => __('tasks.label_url'),
            'item.ordering' => __('tasks.label_ordering'),
            'item.status' => __('tasks.label_status'),
            'item.status_notification' => __('tasks.label_status_notify')
        ];
        parent::__construct($this->controller_name);
    }

    public function mount()
    {
        $this->get_user_task_permissions();
    }

    // View or, List
    public function render()
    {
        // Check if has permission to this task
        if ($this->restrict_permission(0)) {
            return view('page_no_access')->layout('layouts.main');
        }

        $items = DB::table(TABLE_SYSTEM_TASKS)->orderBy('ordering', 'ASC')->get()->all();
        $this->items = $this->get_modules_tasks_table_tree($items);

        $this->task_title = 'List';
        return view('livewire.module_task.list')->layout('layouts.main');
    }

    public function getItem($id, $action) // Add or, Edit
    {
        // Check if has permission to this task
        if ($type = $this->restrict_permission($action)) {
            $this->emit("showAlert", "warning", "You do not have $type access.");
        } else {
            $this->item = [
                'id' => 0,
                'name_en' => '',
                'name_bn' => '',
                'type' => '',
                'parent' => 0,
                'url' => '',
                'controller' => '',
                'ordering' => 999,
                'icon' => '',
                'status' => STATUS_ACTIVE,
                'status_notification' => STATUS_NO
            ];
            if (($id > 0) && ($result = SystemModuleTasks::where('id', $id)->first()->toArray())) { // If EDIT Then fetch from DB; Otherwise ADD
                $this->item = $result;
            }

            $this->item_id = $this->item['id'];
            $this->emit("showModalAddEdit");
        }
    }

    public function saveItem()
    {
        // Check if has permission to this task
        if ($type = $this->restrict_permission([1, 2])) {
            $this->emit("showAlert", "warning", "You do not have $type access.");
        } else {
            if ($this->item['type'] == 'TASK') {
                $this->rules['item.controller'] = 'required';
                $this->rules['item.url'] = 'required';
            }
            // Evaluate Validation
            $this->validate();

            DB::beginTransaction();
            try {
                if ($this->item_id > 0) {
                    QueryHelper::update(TABLE_SYSTEM_TASKS, $this->item, ['id' => $this->item_id], $this->controller_name);
                } else {
                    QueryHelper::add(TABLE_SYSTEM_TASKS, $this->item, $this->controller_name);
                }
                DB::commit(); // IF everything okay THEN commit
                $success = true;
            } catch (\Exception $e) {
                DB::rollback();
                $success = false; // ELSE throw exception and rollback
            }

            $this->emit("hideModalAddEdit");
            if ($success) {
                $this->emit("showAlert", "success", "Successfully Saved.");
            } else {
                $this->emit("showAlert", "error", "Failed to Save.");
            }
        }
    }

    public function get_modules_tasks_table_tree($results)
    {
        $children = [];
        foreach ($results as $result) {
            $children[$result->parent]['ids'][$result->id] = $result->id;
            $children[$result->parent]['modules'][$result->id] = (array)$result;
        }
        $level0 = $children[0]['modules'];
        $tree = array();
        foreach ($level0 as $module) {
            $this->get_sub_modules_tasks_tree($module, '', $tree, $children);
        }
        return $tree;
    }

    public function get_sub_modules_tasks_tree($module, $prefix, &$tree, $children)
    {
        $tree[] = array('prefix' => $prefix, 'module_task' => $module);
        $subs = array();
        if (isset($children[$module['id']])) {
            $subs = $children[$module['id']]['modules'];
        }
        if (sizeof($subs) > 0) {
            foreach ($subs as $sub) {
                $this->get_sub_modules_tasks_tree($sub, $prefix . ' - ', $tree, $children);
            }
        }
    }
}
