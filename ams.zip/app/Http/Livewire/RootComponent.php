<?php

namespace App\Http\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\DB;

abstract class RootComponent extends Component
{
    public $max_task_keys;
    public $access_type = [
        'action_0' => 'VIEW',
        'action_1' => 'ADD',
        'action_2' => 'EDIT',
        'action_3' => 'DELETE',
        'action_4' => 'PRINT',
        'action_5' => 'DOWNLOAD',
        'action_6' => 'COLUMN HEADER',
        'action_7' => 'APPROVE',
        'action_8' => 'FORWARD'
    ];

    public $child_controller_class;
    public $task_permissions;

    public function __construct($child_controller_class)
    {
        $this->child_controller_class = $child_controller_class;
        $this->max_task_keys=count($this->access_type);
    }

    public function clearValidationErrors()
    {
        $this->resetErrorBag();
        $this->resetValidation();
    }

    public function get_user_task_permissions()
    {
        $this->task_permissions = [];

        if (isset($this->child_controller_class)) {
            $logged_user = getAuthUser();
            $task = (array)(DB::table(TABLE_SYSTEM_TASKS)->where('controller', $this->child_controller_class)->first());

            if ($task) {
                $task_id = ',' . $task['id'] . ',';
                for ($i = 0; $i <= $this->max_task_keys; $i++) {
                    $key = 'action_' . $i;
                    if ((array_key_exists($key, $logged_user['user_group'])) && !(strpos($logged_user['user_group'][$key], $task_id) === false)) {
                        $this->task_permissions[$key] = 1;
                    } else {
                        $this->task_permissions[$key] = 0;
                    }
                }
            }
        }
    }

    public function restrict_permission($ids)
    {
        if (is_array($ids)) {
            foreach ($ids as $id) {
                $key = 'action_' . $id;
                if (in_array($key, $this->task_permissions) && ($this->task_permissions[$key] == 1)) {
                    return false;
                }
            }
        } elseif (is_int($ids)) {
            $key = 'action_' . $ids;
            if (in_array($key, $this->task_permissions) && ($this->task_permissions[$key] == 1)) {
                return false;
            }
        }
        return $this->access_type[$key]; // If this line executes; Then the task access is restricted.
    }
}
