<?php

namespace App\Http\Livewire;

use Illuminate\Support\Facades\DB;

use App\Models\UserGroups;
use App\HelperClasses\QueryHelper;

class UserGroup extends RootComponent
{
    public $page_title = 'User Group';
    public $task_title;
    public $items;
    public $item;
    public $item_id;

    public $controller_name; // Initialized using constructor

    protected $listeners = ['updateCheckboxes']; // Event Listener form JavaScript

    public function updateCheckboxes($enableCheckboxes, $task_id = 0, $action_key = '')
    {
        $value = ($enableCheckboxes) ? 1 : 0;
        if (($task_id > 0) && ($action_key == '')) {
            $task_data = &$this->item['task_roles'][$task_id];
            foreach ($this->access_type as $access_key => $label) {
                if (isset($task_data[$access_key])) {
                    $task_data[$access_key] = $value;
                }
            }
        } else if (!($task_id > 0) && ($action_key != '')) {
            foreach ($this->item['task_roles'] as &$task_role) {
                if ($task_role['type'] == SYSTEM_TASK) {
                    $task_role[$action_key] = $value;
                }
            }
        } else {
            $this->emit("showAlert", "error", "Something wrong happened.");
        }
    }

    protected $validationAttributes = [];

    protected $rules = [
        'item.name' => 'required|min:3',
        'item.ordering' => 'required|integer',
        'item.status' => 'required'
    ];

    public function __construct()
    {
        $class_parts = explode('\\', __CLASS__);
        $this->controller_name = end($class_parts);
        $this->validationAttributes = [
            'item.name' => __('tasks.label_name'),
            'item.ordering' => __('tasks.label_ordering'),
            'item.status' => __('tasks.label_status')
        ];
        parent::__construct($this->controller_name);
    }

    public function mount()
    {
        $this->get_user_task_permissions();
    }

    // View or, List
    public function render()
    {
        // Check if has permission to this task
        if ($this->restrict_permission(0)) {
            return view('page_no_access')->layout('layouts.main');
        }
        $this->items = UserGroups::orderBy('ordering', 'ASC')->get()->toArray();

        $this->task_title = 'List';
        return view('livewire.user_group.list')->layout('layouts.main');
    }

    public function getItem($id, $action) // Add or, Edit
    {
        // Check if has permission to this task
        if ($type = $this->restrict_permission($action)) {
            $this->emit("showAlert", "warning", "You do not have $type access.");
        } else {
            $this->item = [
                'id' => 0,
                'name' => '',
                'ordering' => 999,
                'status' => STATUS_ACTIVE
            ];
            if (($id > 0) && ($result = UserGroups::where('id', $id)->first()->toArray())) { // If EDIT Then fetch from DB; Otherwise ADD
                $this->item = $result;
            }

            $this->item_id = $this->item['id'];
            $this->emit("showModalAddEdit");
        }
    }

    public function saveItem()
    {
        // Check if has permission to this task
        if ($type = $this->restrict_permission([1, 2])) {
            $this->emit("showAlert", "warning", "You do not have $type access.");
        } else {
            // Evaluate Validation
            $this->validate();

            DB::beginTransaction();

            $data = [
                'name' => $this->item['name'],
                'ordering' => $this->item['ordering'],
                'status' => $this->item['status'],
            ];

            try {
                if ($this->item_id > 0) {
                    QueryHelper::update(TABLE_USER_GROUP, $data, ['id' => $this->item_id], $this->controller_name);
                } else {
                    QueryHelper::add(TABLE_USER_GROUP, $data, $this->controller_name);
                }
                DB::commit(); // IF everything okay THEN commit
                $success = true;
            } catch (\Exception $e) {
                DB::rollback();
                $success = false; // ELSE throw exception and rollback
            }

            $this->emit("hideModalAddEdit");
            if ($success) {
                $this->emit("showAlert", "success", "Successfully Saved.");
            } else {
                $this->emit("showAlert", "error", "Failed to Save.");
            }
        }
    }

    public function getItemRole($id, $action) // Assign Group Role
    {
        // Check if has permission to this task
        if ($type = $this->restrict_permission($action)) {
            $this->emit("showAlert", "warning", "You do not have $type access.");
        } elseif (!($id > 0)) {
            $this->emit("showAlert", "error", "Invalid Try.");
        } else {
            $result = UserGroups::where('id', $id)->first()->toArray(); // If EDIT Then fetch from DB; Otherwise ADD
            $this->item = $this->get_user_groups_with_permissions($result);

            $this->item_id = $this->item['id'];
            $this->emit("showModalGroupRole");
        }
    }

    public function saveItemRole()
    {
        // Check if has permission to this task
        if ($type = $this->restrict_permission(2)) {
            $this->emit("showAlert", "warning", "You do not have $type access.");
        } else {
            // Evaluate Validation
            $this->validate();

            DB::beginTransaction();
            $data = [];
            if ($this->item['task_roles']) {
                foreach ($this->item['task_roles'] as $task_id => $task_role) { // Creating group permission strings
                    for ($i = 0; $i < $this->max_task_keys; $i++) {
                        $key = 'action_' . $i;
                        if (!isset($data[$key]) || (trim($data[$key]) == '')) {
                            $data[$key] = ',';
                        }
                        if (isset($task_role[$key]) && $task_role[$key] > 0) {
                            $data[$key] .= $task_id . ',';
                        }
                    }
                }
            } else {
                $this->emit("showAlert", "warning", "No Tasks Were Found.");
            }

            try {
                if (!($this->item_id > 0)) {
                    $this->emit("showAlert", "error", "Invalid Try.");
                } else {
                    QueryHelper::update(TABLE_USER_GROUP, $data, ['id' => $this->item_id], $this->controller_name);
                }
                DB::commit(); // IF everything okay THEN commit
                $success = true;
            } catch (\Exception $e) {
                DB::rollback();
                $success = false; // ELSE throw exception and rollback
            }

            $this->emit("hideModalGroupRole");
            if ($success) {
                $this->get_user_task_permissions();
                $this->emit("showAlert", "success", "Successfully Saved.");
            } else {
                $this->emit("showAlert", "error", "Failed to Save.");
            }
        }
    }

    public function resetCheckboxes()
    {
        // Do nothing for now.
    }

    public function get_user_groups_with_permissions($data)
    {
        $actions = [];
        foreach ($this->access_type as $access_type => $access_label) {
            $actions[$access_type] = 0;
        }

        $tasks_tree = $this->get_modules_tasks_table_tree();
        $tasks = [];
        foreach ($tasks_tree as $tree) {
            $tasks[$tree['module_task']['id']] = [
                'name' => $tree['prefix'] . $tree['module_task']['name_en'],
                'type' => $tree['module_task']['type'],
            ];
            $tasks[$tree['module_task']['id']] = array_merge($tasks[$tree['module_task']['id']], $actions);
        }

        foreach ($this->access_type as $access_type => $access_label) {
            if (isset($data[$access_type]) && ($data[$access_type] != '') && ($data[$access_type] != ',')) {
                $task_ids = explode(',', trim($data[$access_type], ','));
                foreach ($task_ids as $task_id) {
                    if ($task_id > 0)
                        $tasks[$task_id][$access_type] = 1;
                }
            }
        }
        $data['task_roles'] = $tasks;
        return $data;
    }

    public function get_modules_tasks_table_tree()
    {
        $results = DB::table(TABLE_SYSTEM_TASKS)->orderBy('ordering', 'ASC')->get()->all();
        $children = [];
        foreach ($results as $result) {
            $children[$result->parent]['ids'][$result->id] = $result->id;
            $children[$result->parent]['modules'][$result->id] = (array)$result;
        }
        $level0 = $children[0]['modules'];
        $tree = array();
        foreach ($level0 as $module) {
            $this->get_sub_modules_tasks_tree($module, '', $tree, $children);
        }
        return $tree;
    }

    public function get_sub_modules_tasks_tree($module, $prefix, &$tree, $children)
    {
        $tree[] = array('prefix' => $prefix, 'module_task' => $module);
        $subs = array();
        if (isset($children[$module['id']])) {
            $subs = $children[$module['id']]['modules'];
        }
        if (sizeof($subs) > 0) {
            foreach ($subs as $sub) {
                $this->get_sub_modules_tasks_tree($sub, $prefix . ' - ', $tree, $children);
            }
        }
    }
}
