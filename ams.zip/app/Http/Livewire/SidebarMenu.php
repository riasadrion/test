<?php

namespace App\Http\Livewire;

use Illuminate\Support\Facades\Auth;
use App\Models\SystemModuleTasks;
use Livewire\Component;
use Illuminate\Support\Facades\URL;

class SidebarMenu extends Component
{
    public function render()
    {
        $menus = $this->get_html_menu();
        return view('livewire.sidebar-menu', ['dynamic_menus' => $menus]);
    }

    public function get_html_menu()
    {
        $user = getAuthUser();
        if (!Auth::user() || !($user['user_group_id'] > 0)) { // If user-group not Assigned or, Auth user not available
            return '';
        }

        $action0_tasks = explode(',', trim($user['user_group']['action_0'], ','));

        $tasks = SystemModuleTasks::all();
        $tasks = $tasks->toArray();
        $menu_data = array();
        foreach ($tasks as $task) {
            if ($task['type'] == 'TASK') {
                if (in_array($task['id'], $action0_tasks)) {
                    $menu_data['items'][$task['id']] = $task;
                    $menu_data['children'][$task['parent']][] = $task['id'];
                }
            } else {
                $menu_data['items'][$task['id']] = $task;
                $menu_data['children'][$task['parent']][] = $task['id'];
            }
        }

        $html = '';
        if (isset($menu_data['children'][0])) {
            foreach ($menu_data['children'][0] as $child) {
                $html .= $this->get_html_submenu($child, $menu_data, 1);
            }
        }
        return $html;
    }

    public function get_html_submenu($parent, $menu_data, $level)
    {
        if (isset($menu_data['children'][$parent])) {
            $sub_html = '';
            foreach ($menu_data['children'][$parent] as $child) {
                $sub_html .= $this->get_html_submenu($child, $menu_data, $level + 1);
            }

            $html = '';
            if ($sub_html) {
                if ($level == 1) {
                    $html .= '<li class="nav-item has-treeview">';
                    $html .= '<a href="'.(URL::to('/')).'/#" class="nav-link"><i class="nav-icon fas fa-list"></i> <p>' . $menu_data['items'][$parent]['name_en'] . ' <i class="right fas fa-angle-left"></i></p></a>';
                } else {
                    $html .= '<li class="nav-item has-treeview">';
                    $html .= '<a href="'.(URL::to('/')).'/#" class="nav-link"><i class="nav-icon fas fa-circle"></i> <p>' . $menu_data['items'][$parent]['name_en'] . ' <i class="right fas fa-angle-left"></i></p></a>';
                }

                $html .= '<ul class="nav nav-treeview">';
                $html .= $sub_html;
                $html .= '</ul></li>';
            }
            return $html;

        } else {
            if ($menu_data['items'][$parent]['type'] == 'TASK') {
                return '<li class="nav-item">
                        <a href="' . URL::to(strtolower($menu_data['items'][$parent]['url'])) . '" class="nav-link"><i class="nav-icon far fa-circle"></i> <p>' . $menu_data['items'][$parent]['name_en'] . '</p></a></li>';
            } else {
                return '';
            }
        }
    }
}
