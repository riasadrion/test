<?php

namespace App\Http\Livewire;

use Livewire\Component;

class DataTable extends Component
{
    public function render()
    {
        return view('livewire.data-table');
    }
}
