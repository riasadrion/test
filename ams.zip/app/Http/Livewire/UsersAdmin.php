<?php

namespace App\Http\Livewire;

//use Illuminate\Support\Facades\DB;

use App\HelperClasses\UploadHelper;
use App\Models\UsersAdmins;
use App\Models\Departments;
use App\Models\Designations;

//use App\HelperClasses\QueryHelper;
use Livewire\WithFileUploads;

class UsersAdmin extends RootComponent
{
    use WithFileUploads;

    public $page_title = 'Admin Users';
    public $task_title;
    public $items;
    public $item;
    public $item_id;
    //Extra
    public $designations;
    public $departments;
    public $blood_groups;
    public $picture;

    public $controller_name; // Initialized using constructor

    /*
    protected $validationAttributes = [];
    protected $rules = [
        'item.name' => 'required|min:3',
        'item.ordering' => 'required|integer',
        'item.status' => 'required'
    ];
    */

    public function __construct()
    {
        $class_parts = explode('\\', __CLASS__);
        $this->controller_name = end($class_parts);
        /*$this->validationAttributes = [
            'item.name' => __('tasks.label_name'),
            'item.ordering' => __('tasks.label_ordering'),
            'item.status' => __('tasks.label_status')
        ];*/
        parent::__construct($this->controller_name);

        $this->departments = Departments::all()->toArray();
        $this->designations = Designations::all()->toArray();
        $this->blood_groups = getBloodGroups();

//        echo '<pre>';
//        print_r($this->departments);
//        print_r($this->designations);
//        print_r($this->blood_groups);
//        echo '</pre>';
    }

    public function mount()
    {
        $this->get_user_task_permissions();
    }

    // View or, List
    public function render()
    {
        // Check if has permission to this task
        if ($this->restrict_permission(0)) {
            return view('page_no_access')->layout('layouts.main');
        }
        $this->items = UsersAdmins::with(['user'])->get()->toArray();

        $this->task_title = 'List';
        return view('livewire.users.admin.list')->layout('layouts.main');
    }

    public function getItem($id, $action) // Add or, Edit
    {
        // Check if has permission to this task
        if ($type = $this->restrict_permission($action)) {
            $this->emit("showAlert", "warning", "You do not have $type access.");
        } else {
            $this->item = [
                'id' => 0,
                'user_id' => 0,
                'employee_id' => '',
                'designation_id' => 0,
                'department_id' => 0,
                'date_of_birth' => '',
                'gender' => GENDER_MALE,
                'status_marital' => STATUS_MARITAL_UNMARRIED,
                'address' => '',
                'blood_group' => '',
                'image_path' => '',
                'revision' => 1,
                'user' => [
                    'id' => 0,
                    'username' => '',
                    'user_group_id' => 0,
                    'name' => '',
                    'email' => '',
                    'mobile_no' => '',
                    'status' => STATUS_ACTIVE,
                    'profile_photo_url' => ''
                ]
            ];
            $this->resetUpload(); // Reset file upload element

            if (($id > 0) && ($result = UsersAdmins::with(['user'])->first()->toArray())) { // If EDIT Then fetch from DB; Otherwise ADD
                $this->item = $result;
            }

            $this->item_id = $this->item['id'];
            $this->emit("showModalAddEdit");
        }
    }

    public function savePicture()
    {
        /*$this->validate([
            'picture' => 'image|max:1024', // 1MB Max
        ]);
        //$this->picture->store('photos', 's3');
        die("===>>> ".$this->picture->temporaryUrl());
        UploadHelper::upload_file($pic);*/
    }

    public function resetUpload()
    {
        $this->picture = null;
        $this->emit('resetUpload');
    }
}
