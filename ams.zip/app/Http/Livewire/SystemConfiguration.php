<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\SystemConfigurations;

class SystemConfiguration extends Component
{
    // Add/Edit Items
    public $item_id;
    public $purpose;
    public $config_value;
    public $description;
    public $status;

    // List Items
    public $items;

    // Single Item
    public $item;

    // Enable add/ edit form
    //public $isOpen = 0;

    /*protected $rules = [
        'item.item_id' => 'required|numeric',
        'item.purpose' => 'required|min:5',
        'item.config_value' => 'required',
        'item.description' => 'required',
        'item.status' => 'required',
    ];*/
    protected $validationAttributes = [
        'item.item_id' => 'Id',
        'item.purpose' => 'Configuration Key',
        'item.config_value' => 'Value',
        'item.description' => 'Description',
        'item.status' => 'Status'
    ];

    public function render() // List
    {
        $this->getList();
        return view('livewire.system_configuration.list')->layout('layouts.main');
    }

    public function create()
    {
        $this->resetInputFields();
        //this->openModal();
    }

    public function getList()
    {
        $this->items = SystemConfigurations::all()->toArray();
    }

    private function resetInputFields()
    {
        $this->item_id = 0;
        $this->purpose = '';
        $this->config_value = '';
        $this->description = '';
        $this->status = STATUS_ACTIVE;
    }

    /*public function openModal()
    {
        $this->isOpen = true;
    }

    public function closeModal()
    {
        $this->isOpen = false;
    }*/

    public function getItem($id, $action)
    {
        if ($id == 0) {
            $this->setItem();
        } else {
            $this->setItem(SystemConfigurations::where('id', $id)->first());
        }

        if ($action == 1 || $action == 2) {
            $this->emit("showModalAddEdit");
        } else if ($action == 3) {
            $this->emit("showModalDeleteConfirm");
        }
    }

    public function setItem($item = array())
    {
        $this->item = array();
        $this->item_id = isset($item['id']) ? $item['id'] : 0;
        $this->purpose = isset($item['purpose']) ? $item['purpose'] : '';
        $this->config_value = isset($item['config_value']) ? $item['config_value'] : '';
        $this->description = isset($item['description']) ? $item['description'] : '';
        $this->status = isset($item['status']) ? $item['status'] : STATUS_ACTIVE;
    }

    public function saveItem()
    {
        $this->validate([
            'item.item_id' => 'required|numeric',
            'item.purpose' => 'required|min:5',
            'item.config_value' => 'required',
            'item.description' => 'required',
            'item.status' => 'required',
        ]);

        SystemConfigurations::create($this->item);
        session()->flash('alert_message',"Product Created");
        session()->flash('alert_type',"primary");

        $this->setItem(array());
        $this->emit("hideModalAddEdit");
    }

    /*public $purpose;
    public $config_value;
    public $description;
    public $status;

    protected function rules()
    {
        return [
            'purpose' => 'required',
            'config_value' => 'required|integer|in:0,1',
            'status' => 'required|in:' . STATUS_ACTIVE . ',' . STATUS_INACTIVE
        ];
    }

    public function save()
    {


        $this->validate();

        SystemConfigurations::create([
            'purpose' => $this->purpose,
            'config_value' => $this->config_value,
            'description' => $this->description,
            'status' => $this->status
        ]);

        redirect()->back();
        //redirect('/home/dashboard');
    }

    public function show()
    {
        $items = $this->getList();
        return view('livewire.system-configuration', ['items' => $items]);
    }

    public function getList()
    {
        return SystemConfigurations::all()->toArray();
    }*/
}
