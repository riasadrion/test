$(document).ready(function () {
    // Toast Message Config
    toastr.options = {
        "closeButton": true,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-top-center",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }

    // Toast_Alert Message Pop-up
    Livewire.on('showAlert', function(alertType, alertMesssage){
        if(alertType == 'success')
        {
            toastr.success(alertMesssage);
        }
        else if (alertType == 'error')
        {
            toastr.error(alertMesssage);
        }
        else if (alertType == 'warning')
        {
            toastr.warning(alertMesssage);
        }
        else {
            toastr.info(alertMesssage);
        }
    });
});

function tableToCsv(tableSelector, outputFileName){
    const preparetext = function (text, regex, rep) {
        text = text.replace(/(\r\n|\n|\r)/gm, '');
        text = text.replace(/(\s\s)/gm, ' ');
        text = text.replace(/"/g, '""');
        return text;
    };
    var table = document.querySelector(tableSelector);
    var colHeaders = table.querySelectorAll('tr th');
    var colRows = table.querySelectorAll('tr:not( .headers )');

    var exclude_class = 'csv-exclude'; // `<th>` element having this class will be excluded in downloaded
    var index = -1;
    var headers = [];
    var data = [];

    colHeaders.forEach(function (th, i) {
        if(th.classList.contains(exclude_class) == false){
            headers.push([ '"', preparetext(th.textContent), '"' ].join(''));
        }else{
            index = i;
        }
    });

    data.push(headers.join(','));
    data.push(String.fromCharCode(10));

    if (index > -1) {
        colRows.forEach(function (tr) {
            var cells = tr.querySelectorAll('td');
            var row = [];
            cells.forEach(function (td, i) {
                if(td.classList.contains(exclude_class) == false){
                    row.push([ '"', preparetext(td.textContent), '"' ].join(''));
                }
            });
            data.push(row.join(','));
            data.push(String.fromCharCode(10));
        });

        var a = document.createElement('a');
        a.download = 'export_' + outputFileName + '.csv';
        a.href = URL.createObjectURL(new Blob(data));
        a.click();
    }
}
