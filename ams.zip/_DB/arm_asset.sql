-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3308
-- Generation Time: Jun 27, 2021 at 02:19 AM
-- Server version: 5.7.24
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `arm_asset`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2014_10_12_200000_add_two_factor_columns_to_users_table', 2),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 2),
(6, '2021_04_24_064905_create_sessions_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('program4@malikseeds.com', '$2y$10$Kbv2e6B2mi8Yp5S3iGwcqO2tcHpIxo0hv/z16KSWgRmGLXkAzrMo6', '2021-06-07 21:34:23');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('7eeDDAZtSfETY2GwZ2GHqzGNDXWXBiiTU74sLAbV', 1, '192.168.5.70', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36', 'YTo3OntzOjY6Il90b2tlbiI7czo0MDoiRjJyQkUyMUE1UjV4a2FSa25yTmpXN2VheTV2WEVScVBWeEl2S2YydiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjM2OiJodHRwOi8vMTkyLjE2OC41LjcwOjgwOTAvdXNlcnNfYWRtaW4iO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6MTc6InBhc3N3b3JkX2hhc2hfd2ViIjtzOjYwOiIkMnkkMTAkTmkwZ2NCL2tqOGlRb0o1RERqWG4uLlVEaktZWjlTQi9WbEE1NEpyZmlOLjlpLm1nOFJ6c3kiO3M6MjE6InBhc3N3b3JkX2hhc2hfc2FuY3R1bSI7czo2MDoiJDJ5JDEwJE5pMGdjQi9rajhpUW9KNUREalhuLi5VRGpLWVo5U0IvVmxBNTRKcmZpTi45aS5tZzhSenN5Ijt9', 1624528323),
('tcuRgbbhg2NkqL8n6cVRu5wgPqfgDsghpjq2JA9h', 1, '192.168.5.70', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36', 'YTo3OntzOjY6Il90b2tlbiI7czo0MDoiSVY1c0U5alZaVms4U1c1b3BjYWM4TDVwQ3kwTHp5eGdmZHBIMWxFciI7czozOiJ1cmwiO2E6MDp7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7czoxNzoicGFzc3dvcmRfaGFzaF93ZWIiO3M6NjA6IiQyeSQxMCROaTBnY0Iva2o4aVFvSjVERGpYbi4uVURqS1laOVNCL1ZsQTU0SnJmaU4uOWkubWc4UnpzeSI7czoyMToicGFzc3dvcmRfaGFzaF9zYW5jdHVtIjtzOjYwOiIkMnkkMTAkTmkwZ2NCL2tqOGlRb0o1RERqWG4uLlVEaktZWjlTQi9WbEE1NEpyZmlOLjlpLm1nOFJ6c3kiO3M6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjM2OiJodHRwOi8vMTkyLjE2OC41LjcwOjgwOTAvdXNlcnNfYWRtaW4iO319', 1624760076);

-- --------------------------------------------------------

--
-- Table structure for table `system_configurations`
--

CREATE TABLE `system_configurations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `purpose` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_configurations`
--

INSERT INTO `system_configurations` (`id`, `purpose`, `description`, `config_value`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'SITE_OFF_LINE', 'Making the application go offline.', '0', 'Active', 1, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `system_history`
--

CREATE TABLE `system_history` (
  `id` int(11) NOT NULL,
  `controller` varchar(255) DEFAULT NULL,
  `table_id` int(11) NOT NULL,
  `table_name` varchar(255) NOT NULL,
  `data` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` varchar(20) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `system_history`
--

INSERT INTO `system_history` (`id`, `controller`, `table_id`, `table_name`, `data`, `user_id`, `action`, `date`) VALUES
(1, 'SystemModuleTask', 4, 'system_tasks', '{\"id\":4,\"name_en\":\"Users\",\"name_bn\":\"\\u09ac\\u09cd\\u09af\\u09ac\\u09b9\\u09be\\u09b0\\u0995\\u09be\\u09b0\\u09c0\",\"type\":\"MODULE\",\"parent\":0,\"url\":\"\",\"controller\":\"\",\"ordering\":4,\"icon\":\"\",\"status\":\"Active\",\"status_notification\":\"No\",\"created_at\":null,\"created_by\":null,\"updated_at\":null,\"updated_by\":null}', 1, 'UPDATE', '2021-06-17 03:44:18'),
(2, 'SystemModuleTask', 4, 'system_tasks', '{\"id\":4,\"name_en\":\"Users\",\"name_bn\":\"\\u09ac\\u09cd\\u09af\\u09ac\\u09b9\\u09be\\u09b0\\u0995\\u09be\\u09b0\\u09c0\",\"type\":\"MODULE\",\"parent\":0,\"url\":\"\",\"controller\":\"\",\"ordering\":4,\"icon\":\"\",\"status\":\"In-Active\",\"status_notification\":\"Yes\",\"created_at\":null,\"created_by\":null,\"updated_at\":null,\"updated_by\":null}', 1, 'UPDATE', '2021-06-17 03:47:15'),
(3, 'SystemModuleTask', 4, 'system_tasks', '{\"id\":4,\"name_en\":\"Users\",\"name_bn\":\"\\u09ac\\u09cd\\u09af\\u09ac\\u09b9\\u09be\\u09b0\\u0995\\u09be\\u09b0\\u09c0\",\"type\":\"MODULE\",\"parent\":0,\"url\":\"\",\"controller\":\"\",\"ordering\":4,\"icon\":\"\",\"status\":\"Active\",\"status_notification\":\"No\",\"created_at\":null,\"created_by\":null,\"updated_at\":null,\"updated_by\":null}', 1, 'UPDATE', '2021-06-17 03:53:21'),
(4, 'SystemModuleTask', 4, 'system_tasks', '{\"id\":4,\"name_en\":\"Users\",\"name_bn\":\"\\u09ac\\u09cd\\u09af\\u09ac\\u09b9\\u09be\\u09b0\\u0995\\u09be\\u09b0\\u09c0\",\"type\":\"MODULE\",\"parent\":0,\"url\":\"\",\"controller\":\"\",\"ordering\":4,\"icon\":\"\",\"status\":\"Active\",\"status_notification\":\"Yes\",\"created_at\":null,\"created_by\":null,\"updated_at\":null,\"updated_by\":null}', 1, 'UPDATE', '2021-06-17 03:58:23'),
(5, 'SystemModuleTask', 4, 'system_tasks', '{\"id\":4,\"name_en\":\"Users\",\"name_bn\":\"\\u09ac\\u09cd\\u09af\\u09ac\\u09b9\\u09be\\u09b0\\u0995\\u09be\\u09b0\\u09c0\",\"type\":\"MODULE\",\"parent\":0,\"url\":\"\",\"controller\":\"\",\"ordering\":4,\"icon\":\"\",\"status\":\"Active\",\"status_notification\":\"No\",\"created_at\":null,\"created_by\":null,\"updated_at\":null,\"updated_by\":null}', 1, 'UPDATE', '2021-06-17 03:58:42'),
(6, 'SystemModuleTask', 4, 'system_tasks', '{\"id\":4,\"name_en\":\"Users\",\"name_bn\":\"\\u09ac\\u09cd\\u09af\\u09ac\\u09b9\\u09be\\u09b0\\u0995\\u09be\\u09b0\\u09c0\",\"type\":\"MODULE\",\"parent\":0,\"url\":\"\",\"controller\":\"\",\"ordering\":4,\"icon\":\"\",\"status\":\"Active\",\"status_notification\":\"Yes\",\"created_at\":null,\"created_by\":null,\"updated_at\":null,\"updated_by\":null}', 1, 'UPDATE', '2021-06-17 05:55:14'),
(7, 'SystemModuleTask', 4, 'system_tasks', '{\"id\":4,\"name_en\":\"Users\",\"name_bn\":\"\\u09ac\\u09cd\\u09af\\u09ac\\u09b9\\u09be\\u09b0\\u0995\\u09be\\u09b0\\u09c0\",\"type\":\"MODULE\",\"parent\":0,\"url\":\"\",\"controller\":\"\",\"ordering\":4,\"icon\":\"\",\"status\":\"Active\",\"status_notification\":\"No\",\"created_at\":null,\"created_by\":null,\"updated_at\":null,\"updated_by\":null}', 1, 'UPDATE', '2021-06-17 05:55:27'),
(8, 'SystemModuleTask', 4, 'system_tasks', '{\"id\":4,\"name_en\":\"Users\",\"name_bn\":\"\\u09ac\\u09cd\\u09af\\u09ac\\u09b9\\u09be\\u09b0\\u0995\\u09be\\u09b0\\u09c0\",\"type\":\"MODULE\",\"parent\":0,\"url\":\"\",\"controller\":\"\",\"ordering\":4,\"icon\":\"\",\"status\":\"Active\",\"status_notification\":\"Yes\",\"created_at\":null,\"created_by\":null,\"updated_at\":null,\"updated_by\":null}', 1, 'UPDATE', '2021-06-17 06:55:45'),
(9, 'SystemModuleTask', 4, 'system_tasks', '{\"id\":4,\"name_en\":\"Users\",\"name_bn\":\"\\u09ac\\u09cd\\u09af\\u09ac\\u09b9\\u09be\\u09b0\\u0995\\u09be\\u09b0\\u09c0\",\"type\":\"MODULE\",\"parent\":0,\"url\":\"\",\"controller\":\"\",\"ordering\":4,\"icon\":\"\",\"status\":\"Active\",\"status_notification\":\"No\",\"created_at\":null,\"created_by\":null,\"updated_at\":null,\"updated_by\":null}', 1, 'UPDATE', '2021-06-17 06:59:22'),
(10, 'SystemModuleTask', 4, 'system_tasks', '{\"id\":4,\"name_en\":\"Users\",\"name_bn\":\"\\u09ac\\u09cd\\u09af\\u09ac\\u09b9\\u09be\\u09b0\\u0995\\u09be\\u09b0\\u09c0\",\"type\":\"MODULE\",\"parent\":0,\"url\":\"\",\"controller\":\"\",\"ordering\":4,\"icon\":\"\",\"status\":\"In-Active\",\"status_notification\":\"No\",\"created_at\":null,\"created_by\":null,\"updated_at\":null,\"updated_by\":null}', 1, 'UPDATE', '2021-06-17 07:49:23'),
(11, 'SystemModuleTask', 4, 'system_tasks', '{\"id\":4,\"name_en\":\"Users\",\"name_bn\":\"\\u09ac\\u09cd\\u09af\\u09ac\\u09b9\\u09be\\u09b0\\u0995\\u09be\\u09b0\\u09c0\",\"type\":\"MODULE\",\"parent\":0,\"url\":\"\",\"controller\":\"\",\"ordering\":4,\"icon\":\"\",\"status\":\"Active\",\"status_notification\":\"No\",\"created_at\":null,\"created_by\":null,\"updated_at\":null,\"updated_by\":null}', 1, 'UPDATE', '2021-06-17 07:49:32'),
(12, 'SystemModuleTask', 4, 'system_tasks', '{\"id\":4,\"name_en\":\"Users\",\"name_bn\":\"\\u09ac\\u09cd\\u09af\\u09ac\\u09b9\\u09be\\u09b0\\u0995\\u09be\\u09b0\\u09c0\",\"type\":\"MODULE\",\"parent\":0,\"url\":\"\",\"controller\":\"\",\"ordering\":4,\"icon\":\"\",\"status\":\"Active\",\"status_notification\":\"Yes\",\"created_at\":null,\"created_by\":null,\"updated_at\":null,\"updated_by\":null}', 1, 'UPDATE', '2021-06-19 05:46:55'),
(13, 'SystemModuleTask', 4, 'system_tasks', '{\"id\":4,\"name_en\":\"Users\",\"name_bn\":\"\\u09ac\\u09cd\\u09af\\u09ac\\u09b9\\u09be\\u09b0\\u0995\\u09be\\u09b0\\u09c0\",\"type\":\"MODULE\",\"parent\":0,\"url\":\"\",\"controller\":\"\",\"ordering\":4,\"icon\":\"\",\"status\":\"Active\",\"status_notification\":\"No\",\"created_at\":null,\"created_by\":null,\"updated_at\":null,\"updated_by\":null}', 1, 'UPDATE', '2021-06-19 05:47:07'),
(14, 'UserGroup', 1, 'user_groups', '{\"name\":\"Super Admin 2\",\"ordering\":1,\"status\":\"Active\"}', 1, 'UPDATE', '2021-06-20 06:34:21'),
(15, 'UserGroup', 1, 'user_groups', '{\"name\":\"Super Admin 4\",\"ordering\":\"123\",\"status\":\"In-Active\"}', 1, 'UPDATE', '2021-06-20 06:34:35'),
(16, 'UserGroup', 1, 'user_groups', '{\"name\":\"Super Admin\",\"ordering\":\"1\",\"status\":\"Active\"}', 1, 'UPDATE', '2021-06-20 06:34:49'),
(17, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",2,3,\",\"action_2\":\",2,3,\",\"action_3\":\",\",\"action_4\":\",2,3,\",\"action_5\":\",2,3,\",\"action_6\":\",\",\"action_7\":\",3,\",\"action_8\":\",2,3,\"}', 1, 'UPDATE', '2021-06-20 09:29:23'),
(18, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",2,3,\",\"action_2\":\",2,3,\",\"action_3\":\",\",\"action_4\":\",2,3,\",\"action_5\":\",3,\",\"action_6\":\",\",\"action_7\":\",\",\"action_8\":\",\"}', 1, 'UPDATE', '2021-06-20 09:31:45'),
(19, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",2,3,\",\"action_2\":\",2,3,\",\"action_3\":\",\",\"action_4\":\",3,\",\"action_5\":\",3,\",\"action_6\":\",\",\"action_7\":\",\",\"action_8\":\",\"}', 1, 'UPDATE', '2021-06-20 09:31:53'),
(20, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",3,\",\"action_2\":\",2,3,\",\"action_3\":\",\",\"action_4\":\",3,\",\"action_5\":\",3,\",\"action_6\":\",\",\"action_7\":\",\",\"action_8\":\",\"}', 1, 'UPDATE', '2021-06-20 09:32:13'),
(21, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",3,\",\"action_2\":\",2,3,\",\"action_3\":\",\",\"action_4\":\",3,\",\"action_5\":\",2,3,\",\"action_6\":\",\",\"action_7\":\",\",\"action_8\":\",\"}', 1, 'UPDATE', '2021-06-20 09:32:22'),
(22, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",3,\",\"action_2\":\",2,3,\",\"action_3\":\",\",\"action_4\":\",2,3,\",\"action_5\":\",2,3,\",\"action_6\":\",\",\"action_7\":\",\",\"action_8\":\",\"}', 1, 'UPDATE', '2021-06-20 09:32:45'),
(23, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",3,\",\"action_2\":\",2,3,\",\"action_3\":\",2,\",\"action_4\":\",2,3,\",\"action_5\":\",2,3,\",\"action_6\":\",\",\"action_7\":\",\",\"action_8\":\",\"}', 1, 'UPDATE', '2021-06-20 09:32:57'),
(24, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",2,3,\",\"action_2\":\",2,3,\",\"action_3\":\",\",\"action_4\":\",2,3,\",\"action_5\":\",2,3,\",\"action_6\":\",\",\"action_7\":\",\",\"action_8\":\",\"}', 1, 'UPDATE', '2021-06-20 09:37:18'),
(25, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",2,3,\",\"action_2\":\",2,3,\",\"action_3\":\",2,3,\",\"action_4\":\",2,3,\",\"action_5\":\",2,3,\",\"action_6\":\",2,3,\",\"action_7\":\",3,\",\"action_8\":\",2,\"}', 1, 'UPDATE', '2021-06-22 06:29:04'),
(26, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",2,3,\",\"action_2\":\",2,3,\",\"action_3\":\",\",\"action_4\":\",2,3,\",\"action_5\":\",2,3,\",\"action_6\":\",2,3,\",\"action_7\":\",3,\",\"action_8\":\",2,\"}', 1, 'UPDATE', '2021-06-22 06:37:04'),
(27, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",2,3,\",\"action_2\":\",2,3,\",\"action_3\":\",\",\"action_4\":\",2,3,\",\"action_5\":\",2,\",\"action_6\":\",2,3,\",\"action_7\":\",3,\",\"action_8\":\",2,\"}', 1, 'UPDATE', '2021-06-22 06:38:10'),
(28, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",2,3,\",\"action_2\":\",2,3,\",\"action_3\":\",\",\"action_4\":\",2,3,\",\"action_5\":\",2,3,\",\"action_6\":\",2,3,\",\"action_7\":\",3,\",\"action_8\":\",2,\"}', 1, 'UPDATE', '2021-06-22 06:42:12'),
(29, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",2,3,\",\"action_2\":\",2,3,\",\"action_3\":\",\",\"action_4\":\",2,\",\"action_5\":\",2,\",\"action_6\":\",2,3,\",\"action_7\":\",3,\",\"action_8\":\",2,\"}', 1, 'UPDATE', '2021-06-22 06:45:22'),
(30, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",2,3,\",\"action_2\":\",2,3,\",\"action_3\":\",\",\"action_4\":\",2,3,\",\"action_5\":\",2,\",\"action_6\":\",2,3,\",\"action_7\":\",3,\",\"action_8\":\",2,\"}', 1, 'UPDATE', '2021-06-22 06:46:31'),
(31, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",2,3,\",\"action_2\":\",2,3,\",\"action_3\":\",\",\"action_4\":\",2,3,\",\"action_5\":\",2,3,\",\"action_6\":\",\",\"action_7\":\",\",\"action_8\":\",2,3,\"}', 1, 'UPDATE', '2021-06-22 06:46:47'),
(32, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",2,3,\",\"action_2\":\",2,3,\",\"action_3\":\",\",\"action_4\":\",2,\",\"action_5\":\",2,\",\"action_6\":\",\",\"action_7\":\",\",\"action_8\":\",2,3,\"}', 1, 'UPDATE', '2021-06-22 06:48:07'),
(33, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",2,3,\",\"action_2\":\",2,3,\",\"action_3\":\",\",\"action_4\":\",2,3,\",\"action_5\":\",2,3,\",\"action_6\":\",\",\"action_7\":\",\",\"action_8\":\",2,3,\"}', 1, 'UPDATE', '2021-06-22 06:48:18'),
(34, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",2,3,\",\"action_2\":\",2,3,\",\"action_3\":\",3,\",\"action_4\":\",2,3,\",\"action_5\":\",2,3,\",\"action_6\":\",\",\"action_7\":\",\",\"action_8\":\",2,3,\"}', 1, 'UPDATE', '2021-06-22 06:49:40'),
(35, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",2,3,\",\"action_2\":\",2,3,\",\"action_3\":\",\",\"action_4\":\",2,3,\",\"action_5\":\",2,3,\",\"action_6\":\",\",\"action_7\":\",\",\"action_8\":\",2,3,\"}', 1, 'UPDATE', '2021-06-22 06:50:57'),
(36, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",3,\",\"action_1\":\",3,\",\"action_2\":\",3,\",\"action_3\":\",\",\"action_4\":\",3,\",\"action_5\":\",3,\",\"action_6\":\",\",\"action_7\":\",\",\"action_8\":\",3,\"}', 1, 'UPDATE', '2021-06-22 09:04:43'),
(37, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",2,3,\",\"action_2\":\",2,3,\",\"action_3\":\",\",\"action_4\":\",2,3,\",\"action_5\":\",2,3,\",\"action_6\":\",\",\"action_7\":\",\",\"action_8\":\",\"}', 1, 'UPDATE', '2021-06-22 09:05:45'),
(38, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",2,3,\",\"action_2\":\",2,3,\",\"action_3\":\",\",\"action_4\":\",2,3,\",\"action_5\":\",2,\",\"action_6\":\",\",\"action_7\":\",\",\"action_8\":\",\"}', 1, 'UPDATE', '2021-06-22 09:07:00'),
(39, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,\",\"action_1\":\",2,3,\",\"action_2\":\",2,3,\",\"action_3\":\",\",\"action_4\":\",2,3,\",\"action_5\":\",2,3,\",\"action_6\":\",\",\"action_7\":\",\",\"action_8\":\",\"}', 1, 'UPDATE', '2021-06-22 09:07:05'),
(40, 'SystemModuleTask', 5, 'system_tasks', '{\"id\":0,\"name_en\":\"Admin\",\"name_bn\":\"\\u098f\\u09a1\\u09ae\\u09bf\\u09a8\",\"type\":\"TASK\",\"parent\":\"4\",\"url\":\"user_admin\",\"controller\":\"UserAdmin\",\"ordering\":\"5\",\"icon\":\"\",\"status\":\"Active\",\"status_notification\":\"No\"}', 1, 'INSERT', '2021-06-22 10:08:21'),
(41, 'SystemModuleTask', 5, 'system_tasks', '{\"id\":5,\"name_en\":\"Admin\",\"name_bn\":\"\\u098f\\u09a1\\u09ae\\u09bf\\u09a8\",\"type\":\"TASK\",\"parent\":4,\"url\":\"user\\/admin\",\"controller\":\"UserAdmin\",\"ordering\":5,\"icon\":\"\",\"status\":\"Active\",\"status_notification\":\"No\",\"created_at\":null,\"created_by\":null,\"updated_at\":null,\"updated_by\":null}', 1, 'UPDATE', '2021-06-22 10:09:41'),
(42, 'UserGroup', 1, 'user_groups', '{\"action_0\":\",2,3,5,\",\"action_1\":\",2,3,5,\",\"action_2\":\",2,3,5,\",\"action_3\":\",\",\"action_4\":\",2,3,5,\",\"action_5\":\",2,3,5,\",\"action_6\":\",\",\"action_7\":\",\",\"action_8\":\",\"}', 1, 'UPDATE', '2021-06-22 10:10:45'),
(43, 'SystemModuleTask', 5, 'system_tasks', '{\"id\":5,\"name_en\":\"Admin\",\"name_bn\":\"\\u098f\\u09a1\\u09ae\\u09bf\\u09a8\",\"type\":\"TASK\",\"parent\":4,\"url\":\"users\\/admin\",\"controller\":\"UserAdmin\",\"ordering\":5,\"icon\":\"\",\"status\":\"Active\",\"status_notification\":\"No\",\"created_at\":null,\"created_by\":null,\"updated_at\":null,\"updated_by\":null}', 1, 'UPDATE', '2021-06-23 06:11:19'),
(44, 'SystemModuleTask', 5, 'system_tasks', '{\"id\":5,\"name_en\":\"Admin\",\"name_bn\":\"\\u098f\\u09a1\\u09ae\\u09bf\\u09a8\",\"type\":\"TASK\",\"parent\":\"3\",\"url\":\"users\\/admin\",\"controller\":\"UserAdmin\",\"ordering\":5,\"icon\":\"\",\"status\":\"Active\",\"status_notification\":\"No\",\"created_at\":null,\"created_by\":null,\"updated_at\":null,\"updated_by\":null}', 1, 'UPDATE', '2021-06-24 04:51:43'),
(45, 'SystemModuleTask', 5, 'system_tasks', '{\"id\":5,\"name_en\":\"Admin\",\"name_bn\":\"\\u098f\\u09a1\\u09ae\\u09bf\\u09a8\",\"type\":\"TASK\",\"parent\":\"4\",\"url\":\"users\\/admin\",\"controller\":\"UserAdmin\",\"ordering\":5,\"icon\":\"\",\"status\":\"Active\",\"status_notification\":\"No\",\"created_at\":null,\"created_by\":null,\"updated_at\":null,\"updated_by\":null}', 1, 'UPDATE', '2021-06-24 05:13:11'),
(46, 'SystemModuleTask', 5, 'system_tasks', '{\"id\":5,\"name_en\":\"Admin\",\"name_bn\":\"\\u098f\\u09a1\\u09ae\\u09bf\\u09a8\",\"type\":\"TASK\",\"parent\":4,\"url\":\"users_admin\",\"controller\":\"UserAdmin\",\"ordering\":5,\"icon\":\"\",\"status\":\"Active\",\"status_notification\":\"No\",\"created_at\":null,\"created_by\":null,\"updated_at\":null,\"updated_by\":null}', 1, 'UPDATE', '2021-06-24 05:17:18'),
(47, 'SystemModuleTask', 5, 'system_tasks', '{\"id\":5,\"name_en\":\"Admin\",\"name_bn\":\"\\u098f\\u09a1\\u09ae\\u09bf\\u09a8\",\"type\":\"TASK\",\"parent\":4,\"url\":\"users_admin\",\"controller\":\"UsersAdmin\",\"ordering\":5,\"icon\":\"\",\"status\":\"Active\",\"status_notification\":\"No\",\"created_at\":null,\"created_by\":null,\"updated_at\":null,\"updated_by\":null}', 1, 'UPDATE', '2021-06-24 05:20:10');

-- --------------------------------------------------------

--
-- Table structure for table `system_tasks`
--

CREATE TABLE `system_tasks` (
  `id` int(11) NOT NULL,
  `name_en` varchar(100) NOT NULL,
  `name_bn` varchar(100) NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'TASK',
  `parent` int(3) NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL,
  `controller` varchar(100) NOT NULL DEFAULT '',
  `ordering` mediumint(4) NOT NULL DEFAULT '9999',
  `icon` varchar(255) NOT NULL DEFAULT 'fas fa-circle',
  `status` varchar(11) NOT NULL DEFAULT 'Active',
  `status_notification` varchar(3) NOT NULL DEFAULT 'No',
  `created_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `system_tasks`
--

INSERT INTO `system_tasks` (`id`, `name_en`, `name_bn`, `type`, `parent`, `url`, `controller`, `ordering`, `icon`, `status`, `status_notification`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 'System Settings', 'সিস্টেম সেটিংস্‌', 'MODULE', 0, '', '', 1, 'fas fa-list', 'Active', 'No', '2021-06-13 02:49:36', 1, NULL, NULL),
(2, 'Module & Task', 'মডিউল এবং টাস্ক', 'TASK', 1, 'system_module_task', 'SystemModuleTask', 2, 'fas fa-circle', 'Active', 'No', '2021-06-13 06:52:17', 1, '2021-06-13 06:52:17', NULL),
(3, 'User Group', 'ইউজার গোষ্ঠী', 'TASK', 1, 'user_group', 'UserGroup', 3, 'fas fa-circle', 'Active', 'No', '2021-06-13 03:11:45', 1, '2021-06-13 03:11:45', NULL),
(4, 'Users', 'ব্যবহারকারী', 'MODULE', 0, '', '', 4, '', 'Active', 'No', NULL, NULL, NULL, NULL),
(5, 'Admin', 'এডমিন', 'TASK', 4, 'users_admin', 'UsersAdmin', 5, '', 'Active', 'No', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_group_id` int(3) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_no` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `user_group_id`, `name`, `email`, `mobile_no`, `two_factor_recovery_codes`, `remember_token`, `created_at`, `email_verified_at`, `two_factor_secret`, `updated_at`) VALUES
(1, '0500454', '$2y$10$Ni0gcB/kj8iQoJ5DDjXn..UDjKYZ9SB/VlA54JrfiN.9i.mg8Rzsy', 1, 'Mahmud Hassan', 'program4@malikseeds.com', '01755511941', NULL, NULL, '2021-04-24 00:52:57', NULL, NULL, '2021-06-09 20:32:26');

-- --------------------------------------------------------

--
-- Table structure for table `user_details_admin`
--

CREATE TABLE `user_details_admin` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `employee_id` varchar(20) NOT NULL,
  `designation_id` int(11) NOT NULL DEFAULT '0',
  `department_id` int(11) NOT NULL DEFAULT '0',
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `status_marital` varchar(20) DEFAULT NULL,
  `address` text,
  `blood_group` varchar(20) DEFAULT NULL,
  `image_path` text,
  `revision` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_details_admin`
--

INSERT INTO `user_details_admin` (`id`, `user_id`, `employee_id`, `designation_id`, `department_id`, `date_of_birth`, `gender`, `status_marital`, `address`, `blood_group`, `image_path`, `revision`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 1, '0454', 0, 0, '1991-09-28', 'Male', 'Married', 'Aftabnagar, Badda, Dhaka-1229', 'B+', NULL, 1, '2021-06-24 06:46:25', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

CREATE TABLE `user_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `status` varchar(11) CHARACTER SET utf8 NOT NULL DEFAULT 'Active',
  `ordering` int(4) NOT NULL DEFAULT '99',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `action_0` varchar(500) CHARACTER SET utf8 NOT NULL DEFAULT ',' COMMENT 'VIEW',
  `action_1` varchar(500) CHARACTER SET utf8 NOT NULL DEFAULT ',' COMMENT 'ADD',
  `action_2` varchar(500) CHARACTER SET utf8 NOT NULL DEFAULT ',' COMMENT 'EDIT',
  `action_3` varchar(500) CHARACTER SET utf8 NOT NULL DEFAULT ',' COMMENT 'DELETE',
  `action_4` varchar(500) CHARACTER SET utf8 NOT NULL DEFAULT ',' COMMENT 'PRINT',
  `action_5` varchar(500) CHARACTER SET utf8 NOT NULL DEFAULT ',' COMMENT 'DOWNLOAD',
  `action_6` varchar(500) CHARACTER SET utf8 NOT NULL DEFAULT ',' COMMENT 'COLUMN_HEADER',
  `action_7` varchar(500) CHARACTER SET utf8 NOT NULL DEFAULT ',' COMMENT 'APPROVE',
  `action_8` varchar(500) CHARACTER SET utf8 NOT NULL DEFAULT ',' COMMENT 'FORWARD'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_groups`
--

INSERT INTO `user_groups` (`id`, `name`, `status`, `ordering`, `created_at`, `created_by`, `updated_at`, `updated_by`, `action_0`, `action_1`, `action_2`, `action_3`, `action_4`, `action_5`, `action_6`, `action_7`, `action_8`) VALUES
(1, 'Super Admin', 'Active', 1, '2021-06-22 10:10:45', 1, '2021-06-22 10:10:45', NULL, ',2,3,5,', ',2,3,5,', ',2,3,5,', ',', ',2,3,5,', ',2,3,5,', ',', ',', ',');

-- --------------------------------------------------------

--
-- Table structure for table `user_type`
--

CREATE TABLE `user_type` (
  `id` int(11) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `prefix` varchar(5) NOT NULL,
  `created_at` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL DEFAULT '0',
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_type`
--

INSERT INTO `user_type` (`id`, `user_type`, `prefix`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 'Employee', '001', 0, 0, NULL, NULL),
(2, 'Admin', '030', 0, 0, NULL, NULL),
(3, 'SuperAdmin', '050', 0, 0, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `system_configurations`
--
ALTER TABLE `system_configurations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_history`
--
ALTER TABLE `system_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_tasks`
--
ALTER TABLE `system_tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_details_admin`
--
ALTER TABLE `user_details_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_groups`
--
ALTER TABLE `user_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_type`
--
ALTER TABLE `user_type`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_configurations`
--
ALTER TABLE `system_configurations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `system_history`
--
ALTER TABLE `system_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `system_tasks`
--
ALTER TABLE `system_tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_details_admin`
--
ALTER TABLE `user_details_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_groups`
--
ALTER TABLE `user_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_type`
--
ALTER TABLE `user_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
