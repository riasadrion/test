<?php

use Illuminate\Support\Facades\Route;

use App\Http\Livewire\SystemModuleTask;
use App\Http\Livewire\UserGroup;
use App\Http\Livewire\UsersAdmin;

Route::middleware(['auth:sanctum', 'verified'])->get('/', function () {
    return view('dashboard');
});

// Authenticated Routes
Route::group(['middleware' => ['auth', 'verified']], function () {

    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');

    // Module Task
    Route::get('/system_module_task', SystemModuleTask::class)->name('system-module-task');
    // User Group
    Route::get('/user_group', UserGroup::class)->name('user-group');
    // Users -MODULE
    Route::get('/users_admin', UsersAdmin::class)->name('users-admin');
    //Route::get('/users_general', UserGeneral::class)->name('user-general');


    // System Configuration
    /*Route::get('/system-configuration', SystemConfiguration::class)->name('system-configuration');
    Route::group(['prefix' => 'system-configuration'], function() {
        Route::get('/', [SystemConfiguration::class, 'show'])->name('system-configuration');
        Route::post('/save', [SystemConfiguration::class, 'save'])->name('system-configuration-save');
    });*/

    // Dynamic Routes from Database
    /*$routes=['link1', 'link2'];
    foreach ($routes as $route){
        Route::get('/'.$route, function (){ return view('dashboard'); }); // Dashboard
        //Route::get('/'.$route, [UserController::class, 'index']);
    }
    */
});
