-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3308
-- Generation Time: May 02, 2021 at 02:55 AM
-- Server version: 5.7.24
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `arm_asset`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2014_10_12_200000_add_two_factor_columns_to_users_table', 2),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 2),
(6, '2021_04_24_064905_create_sessions_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('h7RPsEMiTX7tnT61raHALcFhgKNOTz7B7Unp0Ogf', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.85 Safari/537.36', 'YTo3OntzOjY6Il90b2tlbiI7czo0MDoiWVZTQXNOZjZLb0xvd1NZOE1JeWF0RGwwOXROYm0yY2VVaXNiZTVkTiI7czozOiJ1cmwiO2E6MDp7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7czoxNzoicGFzc3dvcmRfaGFzaF93ZWIiO3M6NjA6IiQyeSQxMCRrcFVWSTdWVGYzaUg2L2w3V3dwNW1Pdi5pck9aZWlyVnNtRExMaEJhZTh5cFZkSWpFbVR5LiI7czoyMToicGFzc3dvcmRfaGFzaF9zYW5jdHVtIjtzOjYwOiIkMnkkMTAka3BVVkk3VlRmM2lINi9sN1d3cDVtT3YuaXJPWmVpclZzbURMTGhCYWU4eXBWZElqRW1UeS4iO3M6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjMxOiJodHRwOi8vMTI3LjAuMC4xOjgwOTAvZGFzaGJvYXJkIjt9fQ==', 1619689000),
('hSC1vd82SGut3yds2LFUTuMxtAJ5wozAVUtrt7TY', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36', 'YTo3OntzOjY6Il90b2tlbiI7czo0MDoiQlc4eEZVbkYwMmYxQUdTN1pIaVVHT3Buc2ZCTnZpZFlWMmRYQ1pqTSI7czozOiJ1cmwiO2E6MDp7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7czoxNzoicGFzc3dvcmRfaGFzaF93ZWIiO3M6NjA6IiQyeSQxMCRrcFVWSTdWVGYzaUg2L2w3V3dwNW1Pdi5pck9aZWlyVnNtRExMaEJhZTh5cFZkSWpFbVR5LiI7czoyMToicGFzc3dvcmRfaGFzaF9zYW5jdHVtIjtzOjYwOiIkMnkkMTAka3BVVkk3VlRmM2lINi9sN1d3cDVtT3YuaXJPWmVpclZzbURMTGhCYWU4eXBWZElqRW1UeS4iO3M6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjIxOiJodHRwOi8vMTI3LjAuMC4xOjgwOTAiO319', 1619923138);

-- --------------------------------------------------------

--
-- Table structure for table `system_configurations`
--

CREATE TABLE `system_configurations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `purpose` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_configurations`
--

INSERT INTO `system_configurations` (`id`, `purpose`, `description`, `config_value`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'SITE_OFF_LINE', 'Making the application go offline.', '0', 'Active', 1, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `system_tasks`
--

CREATE TABLE `system_tasks` (
  `id` int(11) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_bn` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'TASK',
  `parent` int(11) NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL,
  `controller` varchar(255) NOT NULL DEFAULT '',
  `ordering` smallint(6) NOT NULL DEFAULT '9999',
  `icon` varchar(255) NOT NULL DEFAULT 'menu.png',
  `status` varchar(11) NOT NULL DEFAULT 'Active',
  `status_notification` varchar(3) NOT NULL DEFAULT 'No',
  `created_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `system_tasks`
--

INSERT INTO `system_tasks` (`id`, `name_en`, `name_bn`, `type`, `parent`, `url`, `controller`, `ordering`, `icon`, `status`, `status_notification`, `created_at`, `updated_at`) VALUES
(1, 'System Settings', 'পদ্ধতি নির্ধারণ', 'MODULE', 0, '', '', 1, 'menu.png', 'Active', 'No', NULL, NULL),
(2, 'Module & Task', 'মডিউল এবং টাস্ক', 'TASK', 1, '', 'Sys_module_task', 1, 'menu.png', 'In-Active', 'No', NULL, NULL),
(3, 'Configuration', 'কনফিগারেশন', 'TASK', 1, 'system-configuration', 'Sys_configurations', 4, 'menu.png', 'Active', 'No', '2021-04-27 08:26:06', '2021-04-27 08:26:06'),
(4, 'User Group', 'ব্যবহারকারী দল', 'TASK', 1, '', 'Sys_user_group', 2, 'menu.png', 'Active', 'No', NULL, NULL),
(5, 'Setup', 'সেটআপ', 'MODULE', 0, '', '', 2, 'menu.png', 'Active', 'No', '2020-11-19 15:14:59', '2020-11-19 15:14:59'),
(6, 'Users', 'ব্যবহারকারীরা', 'TASK', 5, '', 'Setup_users', 1, 'menu.png', 'Active', 'No', '2020-11-19 15:15:52', '2020-11-19 15:15:52'),
(7, 'Product', 'পণ্য', 'TASK', 5, '', 'Setup_products', 2, 'menu.png', 'Active', 'No', '2020-11-20 18:40:41', '2020-11-20 18:40:41'),
(8, 'Shop', 'দোকান', 'TASK', 0, '', 'Shop', 3, 'menu.png', 'Active', 'No', '2020-11-23 22:35:17', '2020-11-23 22:35:17'),
(9, 'Checout', 'চেকআউট', 'TASK', 0, '', 'Checkout', 4, 'menu.png', 'Active', 'No', NULL, NULL),
(10, 'Stripe Demo', 'স্ট্রাইপ ডেমো', 'TASK', 0, '', 'StripeDemo', 5, 'menu.png', 'Active', 'No', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_group_id` int(3) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `remember_token`, `user_group_id`, `created_at`, `updated_at`) VALUES
(1, 'Mahmud Hassan', 'program4@malikseeds.com', NULL, '$2y$10$kpUVI7VTf3iH6/l7Wwp5mOv.irOZeirVsmDLLhBae8ypVdIjEmTy.', NULL, NULL, NULL, 1, '2021-04-24 00:52:57', '2021-04-27 00:06:27');

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

CREATE TABLE `user_groups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `ordering` smallint(6) NOT NULL DEFAULT '99',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `action_0` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ',',
  `action_1` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ',',
  `action_2` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ',',
  `action_3` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ',',
  `action_4` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ',',
  `action_5` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ',',
  `action_6` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ',',
  `action_7` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ',',
  `action_8` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ','
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_groups`
--

INSERT INTO `user_groups` (`id`, `name`, `status`, `ordering`, `created_at`, `updated_at`, `created_by`, `updated_by`, `action_0`, `action_1`, `action_2`, `action_3`, `action_4`, `action_5`, `action_6`, `action_7`, `action_8`) VALUES
(1, 'Super Admin', 'Active', 99, NULL, NULL, NULL, NULL, ',2,3,4,6,7,8,9,10,', ',2,3,4,6,7,', ',2,3,4,6,7,', ',2,3,4,6,7,', ',2,3,4,6,7,', ',2,3,4,6,7,', ',2,3,4,6,7,', ',2,3,4,6,7,', ',2,3,4,6,7,'),
(2, 'Admin', 'Active', 99, NULL, NULL, NULL, NULL, ',', ',', ',', ',', ',', ',', ',', ',', ','),
(3, 'Visitors', 'Active', 99, NULL, NULL, NULL, NULL, ',8,9,10,', ',', ',', ',', ',', ',', ',', ',', ','),
(4, 'Registered', 'Active', 99, NULL, NULL, NULL, NULL, ',7,8,9,10,', ',', ',', ',', ',7,', ',7,', ',7,', ',7,', ',2,');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `system_configurations`
--
ALTER TABLE `system_configurations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_tasks`
--
ALTER TABLE `system_tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_groups`
--
ALTER TABLE `user_groups`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_configurations`
--
ALTER TABLE `system_configurations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `system_tasks`
--
ALTER TABLE `system_tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_groups`
--
ALTER TABLE `user_groups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
