<div wire:ignore.self class="modal fade" id="modalAddEdit" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form class="form-horizontal">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <input type="hidden" wire:model="item.item_id"/>
                        <?php if(isset($item_id) && ($item_id > 0)): ?>
                            Edit <?php echo e($page_title); ?> :: <?php echo e(__('tasks.label_id')); ?> no. <?php echo e($item_id); ?>

                        <?php else: ?>
                            Add <?php echo e($page_title); ?>

                        <?php endif; ?>
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" wire:click="clearValidationErrors()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label"><?php echo e(__('tasks.label_name')); ?> <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" wire:model="item.name"/>
                            <?php $__errorArgs = ['item.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label"><?php echo e(__('tasks.label_ordering')); ?> <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" wire:model="item.ordering"/>
                            <?php $__errorArgs = ['item.ordering'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label"><?php echo e(__('tasks.label_status')); ?> <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <select class="form-control" wire:model="item.status">
                                <option value="<?php echo e(STATUS_ACTIVE); ?>"><?php echo e(STATUS_ACTIVE); ?></option>
                                <option value="<?php echo e(STATUS_INACTIVE); ?>"><?php echo e(STATUS_INACTIVE); ?></option>
                            </select>
                            <?php $__errorArgs = ['item.status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" wire:click="saveItem()"><?php echo e(__('Save')); ?></button>
                    <button type="button" class="btn btn-secondary" wire:click="clearValidationErrors()" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH I:\laragon\www\ams\resources\views/livewire/user_group/add-edit.blade.php ENDPATH**/ ?>