 <?php $__env->slot('title'); ?> 
    <?php if(isset($page_title)): ?>
    <?php echo e(__($page_title)); ?>

    <?php else: ?>
    <?php echo e(__('Untitled Page')); ?>

    <?php endif; ?>
 <?php $__env->endSlot(); ?>

 <?php $__env->slot('header'); ?> 
    <div class="card-header">
        <h3 class="card-title">
            <?php if(isset($task_title)): ?>
            <?php echo e(__($task_title)); ?>

            <?php else: ?>
            <?php echo e(__('Untitled Task')); ?>

            <?php endif; ?>
        </h3>
    </div>
 <?php $__env->endSlot(); ?>

<div>
    <?php echo $__env->make('livewire.users.admin.add-edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card-body">
        <?php if( $task_permissions['action_1']==1 || $task_permissions['action_4']==1 || $task_permissions['action_5']==1 ): ?>
        <div class="card d-print-none">
            <div class="card-body">
                <div class="button-wrap">
                    <?php if($task_permissions['action_1']==1): ?>
                    <button class="btn btn-sm btn-flat btn-info" wire:click="getItem(0, 1)">
                        <i class="fa fa-plus"></i>&nbsp; <?php echo e(__('Add')); ?>

                    </button>
                    <?php endif; ?>
                    <?php if($task_permissions['action_4']==1): ?>
                    <button class="btn btn-sm btn-flat btn-info" onclick="window.print();">
                        <i class="fa fa-print"></i>&nbsp; <?php echo e(__('Print')); ?>

                    </button>
                    <?php endif; ?>
                    <?php if($task_permissions['action_5']==1): ?>
                    <button class="btn btn-sm btn-flat btn-info" onclick="tableToCsv('#dataList', 'admin_users_list')">
                        <i class="fa fa-download"></i>&nbsp; <?php echo e(__('Download CSV')); ?>

                    </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div class="overflow-x-auto">
            <table class="dataTable table-sm table-bordered table-hover full-width section-to-print" id="dataList">
                <thead>
                    <tr>
                        <th><?php echo e(__('tasks.label_id')); ?></th>
                        <?php if( $task_permissions['action_2']==1 || $task_permissions['action_3']==1 ): ?>
                            <th class="section-not-to-print csv-exclude"><?php echo e(__('tasks.label_action')); ?></th>
                        <?php endif; ?>
                        <th><?php echo e(__('tasks.label_employee_id')); ?></th>
                        <th><?php echo e(__('tasks.label_username')); ?></th>
                        <th><?php echo e(__('tasks.label_name')); ?></th>
                        <th><?php echo e(__('tasks.label_email')); ?></th>
                        <th><?php echo e(__('tasks.label_mobile_no')); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php if($items): ?>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item['id']); ?></td>
                            <?php if($task_permissions['action_2']==1 || $task_permissions['action_3']==1): ?>
                                <td class="section-not-to-print csv-exclude">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-info btn-flat"><?php echo e(__('Action')); ?></button>
                                        <button type="button" class="btn btn-sm btn-info btn-flat dropdown-toggle dropdown-icon" data-toggle="dropdown">
                                            <div class="dropdown-menu" role="menu">
                                                <?php if($task_permissions['action_2']==1): ?>
                                                    <a class="dropdown-item" href="#" wire:click="getItem(<?php echo e($item['user_id']); ?>, 2)"><i class="fa fa-edit"></i>&nbsp; <?php echo e(__('Edit')); ?></a>
                                                <?php endif; ?>
                                                <?php if($task_permissions['action_3']==1): ?>
                                                    <div class="dropdown-divider"></div>
                                                    <a class="dropdown-item" href="#"><i class="fa fa-times"></i>&nbsp; <?php echo e(__('Delete')); ?></a>
                                                <?php endif; ?>
                                            </div>
                                        </button>
                                    </div>
                                </td>
                            <?php endif; ?>
                            <td><?php echo e($item['employee_id']); ?></td>
                            <td><?php echo e($item['user']['username']); ?></td>
                            <td><?php echo e($item['user']['name']); ?></td>
                            <td><?php echo e($item['user']['email']); ?></td>
                            <td><?php echo e($item['user']['mobile_no']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <!-- DataTables Css -->
        <link rel="stylesheet" href="<?php echo e(asset('css/custom/dataTables.bootstrap4.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/custom/responsive.bootstrap4.min.css')); ?>">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css" />
        <!-- DataTables Js -->
        <script src="<?php echo e(asset('js/custom/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/custom/dataTables.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/custom/dataTables.responsive.min.js')); ?>"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
        <script type="text/javascript">
            $( document ).ready(function() {
                //Data-table
                $(".dataTable").DataTable({
                    "responsive": true,
                    "autoWidth": false
                });
                //Date-picker
                $('.input-group.date').datepicker({format: "dd-MM-yyyy", autoclose:true});
                //File-input
                $(document).on("change", ".custom-file-input", function() {
                    var fileName = $(this).val().split("\\").pop();
                    $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
                });
            });
        </script>
    </div>
    <?php $__env->startSection('jsInline'); ?>
    <script>
        Livewire.on('hideModalAddEdit', function(){
            $("#modalAddEdit").modal('hide');
        });
        Livewire.on('showModalAddEdit', function(){
            $("#modalAddEdit").modal('show');
        });
        Livewire.on('resetUpload', function(){
            var field= document.getElementById('uploadPicture');
            field.value= field.defaultValue;
        });
    </script>
    <?php $__env->stopSection(); ?>
</div>
<?php /**PATH I:\laragon\www\ams\resources\views/livewire/users/admin/list.blade.php ENDPATH**/ ?>