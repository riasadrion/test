 <?php $__env->slot('title'); ?> 
    <?php echo e(__('System Configuration')); ?>

 <?php $__env->endSlot(); ?>

 <?php $__env->slot('breadcrumbs'); ?> 
    <ol class="breadcrumb float-sm-right">
        <li class="breadcrumb-item"><a href="#">Home</a></li>
        <li class="breadcrumb-item active">System Settings</li>
        <li class="breadcrumb-item active">Configuration</li>
    </ol>
 <?php $__env->endSlot(); ?>

 <?php $__env->slot('header'); ?> 
    <div class="card-header">
        <h3 class="card-title">System Configuration List</h3>
    </div>
 <?php $__env->endSlot(); ?>

<div class="card-body">
    <div class="button-wrap text-right">
        <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target="#modal-lg">
            <i class="fa fa-plus"></i>&nbsp; Add New
        </button>
    </div>
    <table id="data-table" class="table table-sm table-bordered table-striped">
        <thead>
        <tr>
            <th>ID</th>
            <th>Configuration Key</th>
            <th>Value</th>
            <th>Description</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php if($items): ?>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item['id']); ?></td>
                    <td><?php echo e($item['purpose']); ?></td>
                    <td><?php echo e($item['config_value']); ?></td>
                    <td><?php echo e($item['description']); ?></td>
                    <td><?php echo e($item['status']); ?></td>
                    <td>
                        <button class="btn btn-sm btn-info"><i class="fa fa-edit"></i>&nbsp; Edit</button>
                        <button class="btn btn-sm btn-danger"><i class="fa fa-times"></i>&nbsp; Delete</button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </tbody>
    </table>

    <div class="modal fade" id="modal-lg">
        <div class="modal-dialog modal-lg">
            <form class="form-horizontal" id="submit-form" method="post" action="/system-configuration/save">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Add System Configuration</h4>
                        <button id="close_button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="card-body">
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">Configuration Key</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" wire:model="purpose" />
                                    <?php $__errorArgs = ['purpose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">Value</label>
                                <div class="col-sm-8">
                                    <input type="number" class="form-control" wire:model="config_value" />
                                    <?php $__errorArgs = ['config_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">Description</label>
                                <div class="col-sm-8">
                                    <textarea rows="3" class="form-control" wire:model="description" ></textarea>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">Status</label>
                                <div class="col-sm-8">
                                    <select class="form-control" wire:model="status">
                                        <option value="<?php echo e(STATUS_ACTIVE); ?>"><?php echo e(STATUS_ACTIVE); ?></option>
                                        <option value="<?php echo e(STATUS_INACTIVE); ?>"><?php echo e(STATUS_INACTIVE); ?></option>
                                    </select>
                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-sm btn-danger" id="reset_button" data-dismiss="modal"><i class="fa fa-times"></i>&nbsp; Close</button>
                        <button class="btn btn-sm btn-success"><i class="fa fa-save"></i>&nbsp; Save</button>
                    </div>
                </div>
            </form>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->

    <!-- DataTables Css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/custom/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom/responsive.bootstrap4.min.css')); ?>">
    <!-- DataTables Js -->
    <script src="<?php echo e(asset('js/custom/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom/responsive.bootstrap4.min.js')); ?>"></script>
    <script>
        $(function () {
            $("#data-table").DataTable({
                "responsive": true,
                "autoWidth": false,
            });
            $("#reset_button, #close_button").click((event) => {
                document.getElementById("submit-form").reset();
            });
        });
    </script>
</div>
<?php /**PATH I:\laragon\www\arm_asset\resources\views/livewire/system-configuration.blade.php ENDPATH**/ ?>