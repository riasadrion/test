<div wire:ignore.self class="modal fade" id="modalGroupRole" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <form class="form-horizontal">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <input type="hidden" wire:model="item.item_id"/>
                        Assign <?php echo e($page_title); ?> Role :: <u><?php echo e((isset($item))? $item['name']:''); ?></u> (ID no. <?php echo e($item_id); ?>)
                    </h5>
                    <button type="button" class="close resetCheckboxes" data-dismiss="modal" aria-label="Close" wire:click="resetCheckboxes()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php if(isset($item['task_roles']) && (count($item['task_roles'])>0)): ?>
                        <div class="overflow-auto">
                            <table class="table table-bordered table-hover no-margin">
                                <tr>
                                    <th colspan="2" class="text-center"><?php echo e(__('Task')); ?></th>
                                    <th><?php echo e(__('Type')); ?></th>
                                    <?php $__currentLoopData = $access_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="text-nowrap">
                                            <input type="checkbox" class="action_all" data-key="<?php echo $key ?>" />
                                            <?php echo e(__($type)); ?>

                                        </th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>

                                <?php $__currentLoopData = $item['task_roles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task_key => $task_role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php if($task_role['type'] == SYSTEM_TASK): ?>
                                                <input type="checkbox" class="task_all" data-key="<?php echo $task_key ?>" />
                                            <?php endif; ?>
                                        </td>

                                        <td class="text-nowrap"><?php echo e($task_role['name']); ?></td>

                                        <?php if($task_role['type'] == SYSTEM_TASK): ?>

                                            <td><?php echo e(SYSTEM_TASK); ?></td>
                                            <?php $__currentLoopData = $access_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td class="<?php echo $key.' task_'.$task_key ?>">
                                                    <input type="checkbox" value="1" wire:model="item.task_roles.<?php echo e($task_key); ?>.<?php echo e($key); ?>" <?php echo e(($task_role[$key])? 'checked':''); ?> />
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php else: ?>

                                            <td><?php echo e(SYSTEM_MODULE); ?></td>
                                            <?php $__currentLoopData = $access_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td> &nbsp; </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </table>
                        </div>
                    <?php else: ?>
                        <div class="form-group row">
                            <label class="col-sm-12 col-form-label">- No Task/ Module Found -</label>
                        </div>
                    <?php endif; ?>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" wire:click="saveItemRole()"><?php echo e(__('Save')); ?></button>
                    <button type="button" class="btn btn-secondary resetCheckboxes" wire:click="resetCheckboxes()" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                </div>
            </form>
        </div>
    </div>
    <script type="text/javascript">
        document.addEventListener('livewire:load', function () {
            // ------Reset header checkboxes on Modal close-------
            $(document).on('click', '.resetCheckboxes', function () {
                $('input.action_all, input.task_all').prop('checked', false);
            });

            // ------Select-unselect single action for multiple Tasks------
            $(document).on('click', '.action_all', function () {
                var key = $(this).attr('data-key').trim();
                var isChecked;
                if ($(this).prop("checked") == true) {
                    isChecked = true;
                } else {
                    isChecked = false;
                }
                Livewire.emit('updateCheckboxes', isChecked, 0, key);
                $('td.' + key + ' > input[type="checkbox"]').prop('checked', isChecked);
            });

            // ------Select-unselect multiple action for single Tasks-------
            $(document).on('click', '.task_all', function () {
                var key = $(this).attr('data-key').trim();
                var isChecked;
                if ($(this).prop("checked") == true) {
                    isChecked = true;
                } else {
                    isChecked = false;
                }
                Livewire.emit('updateCheckboxes', isChecked, key, '');
                $('td.task_' + key + ' > input[type="checkbox"]').prop('checked', isChecked);
            });
        })
    </script>
</div>
<?php /**PATH I:\laragon\www\ams\resources\views/livewire/user_group/assign-group-role.blade.php ENDPATH**/ ?>