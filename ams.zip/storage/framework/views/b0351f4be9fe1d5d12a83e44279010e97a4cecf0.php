 <?php $__env->slot('title'); ?> 
    <?php echo e(__('Access Denied')); ?>

 <?php $__env->endSlot(); ?>

 <?php $__env->slot('header'); ?> 
    <div class="card-header">
        <h3 class="card-title text-danger"><?php echo e(__('You do not have access to this page!')); ?></h3>
    </div>
 <?php $__env->endSlot(); ?>

<div>
    &nbsp;
</div>
<?php /**PATH I:\laragon\www\ams\resources\views/page_no_access.blade.php ENDPATH**/ ?>