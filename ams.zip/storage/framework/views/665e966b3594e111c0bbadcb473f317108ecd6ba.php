<nav class="mt-2">
    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Add icons to the links using the .nav-icon class with font-awesome or any other icon font library -->
        <li class="nav-item">
            <a href="<?php echo e(route('dashboard')); ?>" class="nav-link">
                <i class="nav-icon fas fa-tachometer-alt"></i>
                <p>Dashboard</p>
            </a>
        </li>

        <!-------- Dynamic Menus -------->
        <?php if($dynamic_menus): ?>

            <?php echo $dynamic_menus; ?>

        <?php endif ?>

        <!-- Logout (with Authentication) -->
        <li class="nav-item">
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <a href="javascript:void(0);" class="nav-link"
                   onclick="event.preventDefault(); this.closest('form').submit();">
                    <i class="nav-icon fas fa-sign-out-alt"></i>
                    <p>Log Out</p>
                </a>
            </form>
        </li>
    </ul>
</nav>
<?php /**PATH I:\laragon\www\ams\resources\views/livewire/sidebar-menu.blade.php ENDPATH**/ ?>