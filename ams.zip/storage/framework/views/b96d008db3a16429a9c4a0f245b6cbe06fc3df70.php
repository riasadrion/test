<div wire:ignore.self class="modal fade" id="modalAddEdit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form class="form-horizontal">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <input type="hidden" wire:model="item.item_id"/>
                        <?php if(isset($item_id) && ($item_id > 0)): ?>
                            Edit <?php echo e($page_title); ?> :: <?php echo e(__('tasks.label_id')); ?> no. <?php echo e($item_id); ?>

                        <?php else: ?>
                            Add <?php echo e($page_title); ?>

                        <?php endif; ?>
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" wire:click="clearValidationErrors()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label"><?php echo e(__('tasks.label_task_name_en')); ?> <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" wire:model="item.name_en"/>
                            <?php $__errorArgs = ['item.name_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label"><?php echo e(__('tasks.label_task_name_bn')); ?></label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" wire:model="item.name_bn"/>
                            <?php $__errorArgs = ['item.name_bn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label"><?php echo e(__('tasks.label_type')); ?> <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <select class="form-control" wire:model="item.type">
                                <option value="">- Select -</option>
                                <option value="<?php echo e(SYSTEM_MODULE); ?>"><?php echo e(SYSTEM_MODULE); ?></option>
                                <option value="<?php echo e(SYSTEM_TASK); ?>"><?php echo e(SYSTEM_TASK); ?></option>
                            </select>
                            <?php $__errorArgs = ['item.type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label"><?php echo e(__('tasks.label_parent')); ?></label>
                        <div class="col-sm-7">
                            <select class="form-control" wire:model="item.parent">
                                <option value="0">- Select -</option>
                                <?php if($items): ?>
                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($item_row['module_task']['id'] == $item_id): ?>
                                            <?php  continue;  ?>
                                        <?php endif; ?>
                                        <option value="<?php echo e($item_row['module_task']['id']); ?>">
                                            <?php echo e($item_row['prefix'].$item_row['module_task']['name_en']); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                            <?php $__errorArgs = ['item.parent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label"><?php echo e(__('tasks.label_controller')); ?></label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" wire:model="item.controller"/>
                            <?php $__errorArgs = ['item.controller'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label"><?php echo e(__('tasks.label_url')); ?></label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" wire:model="item.url"/>
                            <?php $__errorArgs = ['item.url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label"><?php echo e(__('tasks.label_ordering')); ?> <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" wire:model="item.ordering"/>
                            <?php $__errorArgs = ['item.ordering'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label"><?php echo e(__('tasks.label_status')); ?> <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <select class="form-control" wire:model="item.status">
                                <option value="<?php echo e(STATUS_ACTIVE); ?>"><?php echo e(STATUS_ACTIVE); ?></option>
                                <option value="<?php echo e(STATUS_INACTIVE); ?>"><?php echo e(STATUS_INACTIVE); ?></option>
                            </select>
                            <?php $__errorArgs = ['item.status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label"><?php echo e(__('tasks.label_status_notify')); ?> <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <select class="form-control" wire:model="item.status_notification">
                                <option value="<?php echo e(STATUS_NO); ?>"><?php echo e(STATUS_NO); ?></option>
                                <option value="<?php echo e(STATUS_YES); ?>"><?php echo e(STATUS_YES); ?></option>
                            </select>
                            <?php $__errorArgs = ['item.status_notification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" wire:click="saveItem()"><?php echo e(__('Save')); ?></button>
                    <button type="button" class="btn btn-secondary" wire:click="clearValidationErrors()" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH I:\laragon\www\ams\resources\views/livewire/module_task/add-edit.blade.php ENDPATH**/ ?>