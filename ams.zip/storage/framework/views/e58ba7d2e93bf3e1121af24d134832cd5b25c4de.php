<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH I:\laragon\www\ams\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>