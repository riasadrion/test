 <?php $__env->slot('title'); ?> 
    <?php if(isset($page_title)): ?>
        <?php echo e(__($page_title)); ?>

    <?php else: ?>
        <?php echo e(__('Untitled Page')); ?>

    <?php endif; ?>
 <?php $__env->endSlot(); ?>

 <?php $__env->slot('header'); ?> 
    <div class="card-header">
        <h3 class="card-title">
            <?php if(isset($task_title)): ?>
                <?php echo e(__($task_title)); ?>

            <?php else: ?>
                <?php echo e(__('Untitled Task')); ?>

            <?php endif; ?>
        </h3>
    </div>
 <?php $__env->endSlot(); ?>

<div>
    <?php echo $__env->make('livewire.module_task.add-edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card-body">
        <?php if( $task_permissions['action_1']==1 || $task_permissions['action_4']==1 || $task_permissions['action_5']==1 ): ?>
            <div class="card d-print-none">
                <div class="card-body">
                    <div class="button-wrap">
                        <?php if($task_permissions['action_1']==1): ?>
                            <button class="btn btn-sm btn-flat btn-info" wire:click="getItem(0, 1)">
                                <i class="fa fa-plus"></i>&nbsp; <?php echo e(__('Add')); ?>

                            </button>
                        <?php endif; ?>
                        <?php if($task_permissions['action_4']==1): ?>
                            <button class="btn btn-sm btn-flat btn-info" onclick="window.print();">
                                <i class="fa fa-print"></i>&nbsp; <?php echo e(__('Print')); ?>

                            </button>
                        <?php endif; ?>
                        <?php if($task_permissions['action_5']==1): ?>
                            <button class="btn btn-sm btn-flat btn-info" onclick="tableToCsv('#dataList', 'module_task_list')">
                                <i class="fa fa-download"></i>&nbsp; <?php echo e(__('Download CSV')); ?>

                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="overflow-x-auto">
            <table class="table-sm table-bordered table-hover full-width section-to-print" id="dataList">
                <thead>
                    <tr>
                        <th><?php echo e(__('tasks.label_id')); ?></th>
                        <?php if( $task_permissions['action_2']==1 || $task_permissions['action_3']==1 ): ?>
                            <th class="section-not-to-print csv-exclude"><?php echo e(__('tasks.label_action')); ?></th>
                        <?php endif; ?>
                        <th class="text-nowrap"><?php echo e(__('tasks.label_task_name_en')); ?></th>
                        <th><?php echo e(__('tasks.label_type')); ?></th>
                        <th><?php echo e(__('tasks.label_controller')); ?></th>
                        <th><?php echo e(__('tasks.label_url')); ?></th>
                        <th class="csv-exclude"><?php echo e(__('tasks.label_ordering')); ?></th>
                        <th><?php echo e(__('tasks.label_status')); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php if($items): ?>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item['module_task']['id']); ?></td>
                            <?php if($task_permissions['action_2']==1 || $task_permissions['action_3']==1): ?>
                                <td class="section-not-to-print csv-exclude">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-info btn-flat"><?php echo e(__('Action')); ?></button>
                                        <button type="button" class="btn btn-sm btn-info btn-flat dropdown-toggle dropdown-icon" data-toggle="dropdown">
                                            <div class="dropdown-menu" role="menu">
                                                <?php if($task_permissions['action_2']==1): ?>
                                                    <a class="dropdown-item" href="#" wire:click="getItem(<?php echo e($item['module_task']['id']); ?>, 2)"><i class="fa fa-edit"></i>&nbsp; <?php echo e(__('Edit')); ?></a>
                                                <?php endif; ?>
                                                <?php if($task_permissions['action_3']==1): ?>
                                                    <div class="dropdown-divider"></div>
                                                    <a class="dropdown-item" href="#"><i class="fa fa-times"></i>&nbsp; <?php echo e(__('Delete')); ?></a>
                                                <?php endif; ?>
                                            </div>
                                        </button>
                                    </div>
                                </td>
                            <?php endif; ?>
                            <td class="text-nowrap"><?php echo e($item['prefix'].$item['module_task']['name_en']); ?></td>
                            <td><?php echo e($item['module_task']['type']); ?></td>
                            <td><?php echo e($item['module_task']['controller']); ?></td>
                            <td><?php echo e($item['module_task']['url']); ?></td>
                            <td class="csv-exclude"><?php echo e($item['module_task']['ordering']); ?></td>
                            <td><?php echo e($item['module_task']['status']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php $__env->startSection('jsInline'); ?>
    <script>
        Livewire.on('hideModalAddEdit', function(){
            $("#modalAddEdit").modal('hide');
        });
        Livewire.on('showModalAddEdit', function(){
            $("#modalAddEdit").modal('show');
        });
    </script>
    <?php $__env->stopSection(); ?>
</div>
<?php /**PATH I:\laragon\www\ams\resources\views/livewire/module_task/list.blade.php ENDPATH**/ ?>