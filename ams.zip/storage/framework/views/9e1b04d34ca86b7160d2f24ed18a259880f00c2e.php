<?php if (isset($component)) { $__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MainLayout::class, []); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title'); ?> <?php echo e(__('Dashboard')); ?> <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadcrumbs'); ?> 
        <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header'); ?> 
        <div class="card-header">
            <h3 class="card-title">Welcome</h3>
        </div>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('slot'); ?> 
        <div class="card-body">

            <p>Logged in user : <strong><?php echo e(getAuthUser()['name']); ?></strong></p>

            <?php if(Auth::user() && isset(getAuthUser()['user_group'])): ?>
                <p class="text-success">Assigned Role : <strong><?php echo e(getAuthUser()['user_group']['name']); ?></strong></p>
            <?php else: ?>
                <p class="text-danger">Not assigned to any <strong>User Group</strong> yet. Please contact <strong>Admin</strong>.</p>
            <?php endif; ?>

        </div>
     <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d)): ?>
<?php $component = $__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d; ?>
<?php unset($__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH I:\laragon\www\ams\resources\views/dashboard.blade.php ENDPATH**/ ?>