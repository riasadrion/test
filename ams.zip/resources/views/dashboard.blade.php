<x-main-layout>
    <x-slot name="title">{{ __('Dashboard') }}</x-slot>

    <x-slot name="breadcrumbs">
        <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
    </x-slot>

    <x-slot name="header">
        <div class="card-header">
            <h3 class="card-title">Welcome</h3>
        </div>
    </x-slot>

    <x-slot name="slot">
        <div class="card-body">

            <p>Logged in user : <strong>{{ getAuthUser()['name'] }}</strong></p>

            @if(Auth::user() && isset(getAuthUser()['user_group']))
                <p class="text-success">Assigned Role : <strong>{{ getAuthUser()['user_group']['name'] }}</strong></p>
            @else
                <p class="text-danger">Not assigned to any <strong>User Group</strong> yet. Please contact <strong>Admin</strong>.</p>
            @endif

        </div>
    </x-slot>
</x-main-layout>
