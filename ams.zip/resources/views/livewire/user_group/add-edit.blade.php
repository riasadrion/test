<div wire:ignore.self class="modal fade" id="modalAddEdit" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form class="form-horizontal">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <input type="hidden" wire:model="item.item_id"/>
                        @if(isset($item_id) && ($item_id > 0))
                            Edit {{ $page_title }} :: {{ __('tasks.label_id') }} no. {{ $item_id }}
                        @else
                            Add {{ $page_title }}
                        @endif
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" wire:click="clearValidationErrors()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_name') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" wire:model="item.name"/>
                            @error('item.name') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_ordering') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" wire:model="item.ordering"/>
                            @error('item.ordering') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_status') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <select class="form-control" wire:model="item.status">
                                <option value="{{ STATUS_ACTIVE }}">{{ STATUS_ACTIVE }}</option>
                                <option value="{{ STATUS_INACTIVE }}">{{ STATUS_INACTIVE }}</option>
                            </select>
                            @error('item.status') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" wire:click="saveItem()">{{ __('Save') }}</button>
                    <button type="button" class="btn btn-secondary" wire:click="clearValidationErrors()" data-dismiss="modal">{{ __('Cancel') }}</button>
                </div>
            </form>
        </div>
    </div>
</div>
