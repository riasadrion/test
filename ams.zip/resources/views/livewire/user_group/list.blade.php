<x-slot name="title">
    @if(isset($page_title))
        {{ __($page_title) }}
    @else
        {{ __('Untitled Page') }}
    @endif
</x-slot>

<x-slot name="header">
    <div class="card-header">
        <h3 class="card-title">
            @if(isset($task_title))
                {{ __($task_title) }}
            @else
                {{ __('Untitled Task') }}
            @endif
        </h3>
    </div>
</x-slot>

<div>
    @include('livewire.user_group.add-edit')
    @include('livewire.user_group.assign-group-role')

    <div class="card-body">
        @if( $task_permissions['action_1']==1 || $task_permissions['action_4']==1 || $task_permissions['action_5']==1 )
            <div class="card d-print-none">
                <div class="card-body">
                    <div class="button-wrap">
                        @if ($task_permissions['action_1']==1)
                            <button class="btn btn-sm btn-flat btn-info" wire:click="getItem(0, 1)">
                                <i class="fa fa-plus"></i>&nbsp; {{__('Add')}}
                            </button>
                        @endif
                        @if ($task_permissions['action_4']==1)
                            <button class="btn btn-sm btn-flat btn-info" onclick="window.print();">
                                <i class="fa fa-print"></i>&nbsp; {{__('Print')}}
                            </button>
                        @endif
                        @if ($task_permissions['action_5']==1)
                            <button class="btn btn-sm btn-flat btn-info" onclick="tableToCsv('#dataList', 'user_group_list')">
                                <i class="fa fa-download"></i>&nbsp; {{__('Download CSV')}}
                            </button>
                        @endif
                    </div>
                </div>
            </div>
        @endif

        <div class="overflow-x-auto">
            <table class="table-sm table-bordered table-hover full-width section-to-print" id="dataList">
                <thead>
                    <tr>
                        <th>{{ __('tasks.label_id') }}</th>
                        @if( $task_permissions['action_2']==1 || $task_permissions['action_3']==1 )
                            <th class="section-not-to-print csv-exclude">{{ __('tasks.label_action') }}</th>
                        @endif
                        <th width="60%">{{ __('tasks.label_name') }}</th>
                        <th class="csv-exclude">{{ __('tasks.label_ordering') }}</th>
                        <th>{{ __('tasks.label_status') }}</th>
                    </tr>
                </thead>
                <tbody>
                @if($items)
                    @foreach($items as $item)
                        <tr>
                            <td>{{ $item['id'] }}</td>
                            @if($task_permissions['action_2']==1 || $task_permissions['action_3']==1)
                                <td class="section-not-to-print csv-exclude">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-info btn-flat">{{__('Action')}}</button>
                                        <button type="button" class="btn btn-sm btn-info btn-flat dropdown-toggle dropdown-icon" data-toggle="dropdown">
                                            <div class="dropdown-menu" role="menu">
                                                @if($task_permissions['action_2']==1)
                                                    <a class="dropdown-item" href="#" wire:click="getItem({{ $item['id'] }}, 2)"><i class="fa fa-edit"></i>&nbsp; {{__('Edit')}}</a>
                                                    <div class="dropdown-divider"></div>
                                                    <a class="dropdown-item" href="#" wire:click="getItemRole({{ $item['id'] }}, 2)"><i class="fa fa-user-friends"></i>&nbsp; {{__('Assign Group Role')}}</a>
                                                @endif
                                                @if($task_permissions['action_3']==1)
                                                    <div class="dropdown-divider"></div>
                                                    <a class="dropdown-item" href="#"><i class="fa fa-times"></i>&nbsp; {{__('Delete')}}</a>
                                                @endif
                                            </div>
                                        </button>
                                    </div>
                                </td>
                            @endif
                            <td>{{ $item['name'] }}</td>
                            <td class="csv-exclude">{{ $item['ordering'] }}</td>
                            <td>{{ $item['status'] }}</td>
                        </tr>
                    @endforeach
                @endif
                </tbody>
            </table>
        </div>
    </div>
    @section('jsInline')
    <script>
        Livewire.on('hideModalAddEdit', function(){
            $("#modalAddEdit").modal('hide');
        });
        Livewire.on('showModalAddEdit', function(){
            $("#modalAddEdit").modal('show');
        });
        Livewire.on('hideModalGroupRole', function(){
            $('input.action_all, input.task_all').prop('checked', false);
            $("#modalGroupRole").modal('hide');
        });
        Livewire.on('showModalGroupRole', function(){
            $('input.action_all, input.task_all').prop('checked', false);
            $("#modalGroupRole").modal('show');
        });
    </script>
    @endsection
</div>
