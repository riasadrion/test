<div wire:ignore.self class="modal fade" id="modalAddEdit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form class="form-horizontal">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <input type="hidden" wire:model="item.item_id"/>
                        @if(isset($item_id) && ($item_id > 0))
                            Edit {{ $page_title }} :: {{ __('tasks.label_id') }} no. {{ $item_id }}
                        @else
                            Add {{ $page_title }}
                        @endif
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" wire:click="clearValidationErrors()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_task_name_en') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" wire:model="item.name_en"/>
                            @error('item.name_en') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_task_name_bn') }}</label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" wire:model="item.name_bn"/>
                            @error('item.name_bn') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_type') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <select class="form-control" wire:model="item.type">
                                <option value="">- Select -</option>
                                <option value="{{ SYSTEM_MODULE }}">{{ SYSTEM_MODULE }}</option>
                                <option value="{{ SYSTEM_TASK }}">{{ SYSTEM_TASK }}</option>
                            </select>
                            @error('item.type') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_parent') }}</label>
                        <div class="col-sm-7">
                            <select class="form-control" wire:model="item.parent">
                                <option value="0">- Select -</option>
                                @if($items)
                                    @foreach($items as $item_row)
                                        @if($item_row['module_task']['id'] == $item_id)
                                            @php  continue;  @endphp
                                        @endif
                                        <option value="{{ $item_row['module_task']['id'] }}">
                                            {{ $item_row['prefix'].$item_row['module_task']['name_en'] }}
                                        </option>
                                    @endforeach
                                @endif
                            </select>
                            @error('item.parent') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_controller') }}</label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" wire:model="item.controller"/>
                            @error('item.controller') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_url') }}</label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" wire:model="item.url"/>
                            @error('item.url') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_ordering') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" wire:model="item.ordering"/>
                            @error('item.ordering') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_status') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <select class="form-control" wire:model="item.status">
                                <option value="{{ STATUS_ACTIVE }}">{{ STATUS_ACTIVE }}</option>
                                <option value="{{ STATUS_INACTIVE }}">{{ STATUS_INACTIVE }}</option>
                            </select>
                            @error('item.status') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_status_notify') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <select class="form-control" wire:model="item.status_notification">
                                <option value="{{ STATUS_NO }}">{{ STATUS_NO }}</option>
                                <option value="{{ STATUS_YES }}">{{ STATUS_YES }}</option>
                            </select>
                            @error('item.status_notification') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" wire:click="saveItem()">{{ __('Save') }}</button>
                    <button type="button" class="btn btn-secondary" wire:click="clearValidationErrors()" data-dismiss="modal">{{ __('Cancel') }}</button>
                </div>
            </form>
        </div>
    </div>
</div>
