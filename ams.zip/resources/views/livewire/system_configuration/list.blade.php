<x-slot name="title">
    {{ __('System Configuration') }}
</x-slot>

<x-slot name="breadcrumbs">
    <ol class="breadcrumb float-sm-right">
        <li class="breadcrumb-item"><a href="#">Home</a></li>
        <li class="breadcrumb-item active">System Settings</li>
        <li class="breadcrumb-item active">Configuration</li>
    </ol>
</x-slot>

<x-slot name="header">
    <div class="card-header">
        <h3 class="card-title">System Configuration List</h3>
    </div>
</x-slot>

<div>
    @include('livewire.system_configuration.add-edit')
{{--    @include('livewire.setup-products.confirm-delete')--}}
{{--    @include('livewire.setup-products.pictures')--}}
{{--    @include('livewire.setup-products.confirm-delete-picture')--}}

    <div class="card-body">
        <div>
            @if (session()->has('alert_message'))
                <div class="alert alert-{{ session()->has('alert_type')?session('alert_type'):'success'}} alert-dismissible fade show d-print-none" role="alert">
                    {{ session('alert_message') }}
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            @endif
            <div class="card d-print-none">
                <div class="card-body">
                    <div class="button-wrap">
                        <button wire:click="getItem(0,1)" class="btn btn-sm btn-success">
                            <i class="fa fa-plus"></i>&nbsp; {{__('New')}}
                        </button>
                    </div>
{{--                    @if ($permissions['action_1']==1)--}}
{{--                        <button class="btn btn-primary" wire:click="getItem(0,1)">{{__('New')}}</button>--}}
{{--                    @endif--}}
{{--                    @if ($permissions['action_4']==1)--}}
{{--                        <button class="btn btn-primary"  onclick="window.print();">{{__('Print')}}</button>--}}
{{--                    @endif--}}
{{--                    @if ($permissions['action_5']==1)--}}
{{--                        <button class="btn btn-primary"  wire:click="downloadCsv()">{{__('CSV')}}</button>--}}
{{--                    @endif--}}
                </div>
            </div>
            <div>
                <table id="dataTable" class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Configuration Key</th>
                            <th>Value</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    @if($items)
                        @foreach($items as $item)
                            <tr>
                                <td>{{ $item['id'] }}</td>
                                <td>{{ $item['purpose'] }}</td>
                                <td>{{ $item['config_value'] }}</td>
                                <td>{{ $item['description'] }}</td>
                                <td>{{ $item['status'] }}</td>
                                <td>
                                    <button class="btn btn-sm btn-info"><i class="fa fa-edit"></i>&nbsp; Edit</button>
                                    <button class="btn btn-sm btn-danger"><i class="fa fa-times"></i>&nbsp; Delete</button>
                                </td>
                            </tr>
                        @endforeach
                    @endif
                    </tbody>
                </table>
            </div>
        </div>
        <!-- DataTables Css -->
        <link rel="stylesheet" href="{{ asset('css/custom/dataTables.bootstrap4.min.css') }}">
        <link rel="stylesheet" href="{{ asset('css/custom/responsive.bootstrap4.min.css') }}">
        <!-- DataTables Js -->
        <script src="{{ asset('js/custom/jquery.dataTables.min.js') }}"></script>
        <script src="{{ asset('js/custom/dataTables.bootstrap4.min.js') }}"></script>
        <script src="{{ asset('js/custom/dataTables.responsive.min.js') }}"></script>
        <script src="{{ asset('js/custom/responsive.bootstrap4.min.js') }}"></script>
        <script type="text/javascript">
            $( document ).ready(function() {
                $("#dataTable").DataTable({
                    "responsive": true,
                    "autoWidth": false
                });
            });
        </script>
    </div>
    @section('jsInline')
        <script>
            Livewire.on('hideModalAddEdit', function(){
                $("#modalAddEdit").modal('hide');
            });
            Livewire.on('showModalAddEdit', function(){
                $("#modalAddEdit").modal('show');
            });
             /*Livewire.on('hideModalDeleteConfirm', function(){
                $("#modalConfirmDelete").modal('hide');
            });
            Livewire.on('showModalDeleteConfirm', function(){
                $("#modalConfirmDelete").modal('show');
            });
            Livewire.on('showModalPictures', function(){
                $("#modalPictures").modal('show');
            });
            Livewire.on('hideModalDeleteConfirmPicture', function(){
                $("#modalConfirmDeletePicture").modal('hide');
            });
            Livewire.on('showModalDeleteConfirmPicture', function(){
                $("#modalConfirmDeletePicture").modal('show');
            });
            Livewire.on('resetFile', function(){
                $("#formAddPicture")[0].reset();
            });*/
        </script>
    @endsection
</div>
