<div wire:ignore.self class="modal fade" id="modalAddEdit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form class="form-horizontal">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <input type="hidden" wire:model="item.item_id"/>
                        @if(isset($item['item_id']) && $item['item_id']>0)
                            Edit Configuration :: ID: {{ $item['item_id'] }}
                        @else
                            Add Configuration
                        @endif
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group row">
                        <label class="col-sm-4 col-form-label">Configuration Key</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" wire:model="item.purpose"/>
                            @error('item.purpose') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-4 col-form-label">Value</label>
                        <div class="col-sm-8">
                            <input type="number" class="form-control" wire:model="item.config_value"/>
                            @error('item.config_value') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-4 col-form-label">Description</label>
                        <div class="col-sm-8">
                            <textarea rows="3" class="form-control" wire:model="item.description"></textarea>
                            @error('item.description') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-4 col-form-label">Status</label>
                        <div class="col-sm-8">
                            <select class="form-control" wire:model="item.status">
                                <option value="">Choose ...</option>
                                <option value="{{ STATUS_ACTIVE }}">{{ STATUS_ACTIVE }}</option>
                                <option value="{{ STATUS_INACTIVE }}">{{ STATUS_INACTIVE }}</option>
                            </select>
                            @error('item.status') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" wire:click="saveItem()">Save changes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>
