<div wire:ignore.self class="modal fade" id="modalAddEdit" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form class="form-horizontal">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <input type="hidden" wire:model="item.item_id"/>
                        @if(isset($item_id) && ($item_id > 0))
                            Edit {{ $page_title }} :: {{ __('tasks.label_id') }} no. {{ $item_id }}
                        @else
                            Add {{ $page_title }}
                        @endif
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" wire:click="clearValidationErrors()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_employee_id') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" wire:model="item.employee_id"/>
                            @error('item.employee_id') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_username') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" wire:model="item.user.username"/>
                            @error('item.user.username') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_name') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" wire:model="item.user.name"/>
                            @error('item.user.name') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_email') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" wire:model="item.user.email"/>
                            @error('item.user.email') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_mobile_no') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" wire:model="item.user.mobile_no"/>
                            @error('item.user.mobile_no') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_status') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <select class="form-control" wire:model="item.user.status">
                                <option value="{{ STATUS_ACTIVE }}">{{ STATUS_ACTIVE }}</option>
                                <option value="{{ STATUS_INACTIVE }}">{{ STATUS_INACTIVE }}</option>
                            </select>
                            @error('item.user.status') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>

                    <hr/>

                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_designation') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <select class="form-control" wire:model="item.designation_id"">
                                <option value="">- Select -</option>
                                @foreach($designations as $designation)
                                    <option value="{{ $designation['id'] }}">{{ $designation['name'] }}</option>
                                @endforeach
                            </select>
                            @error('item.designation_id') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_department') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <select class="form-control" wire:model="item.department_id"">
                                <option value="">- Select -</option>
                                @foreach($departments as $department)
                                    <option value="{{ $department['id'] }}">{{ $department['name'] }}</option>
                                @endforeach
                            </select>
                            @error('item.department_id') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_dob') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <div class="input-group date">
                                <input type="text" class="form-control" wire:model="item.date_of_birth" readonly>
                                <div class="input-group-append">
                                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                </div>
                            </div>
                            @error('item.date_of_birth') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_gender') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <select class="form-control" wire:model="item.gender">
                                <option value="{{ GENDER_MALE }}">{{ GENDER_MALE }}</option>
                                <option value="{{ GENDER_FEMALE }}">{{ GENDER_FEMALE }}</option>
                            </select>
                            @error('item.gender') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_status_marital') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <select class="form-control" wire:model="item.status_marital">
                                <option value="{{ STATUS_MARITAL_UNMARRIED }}">{{ STATUS_MARITAL_UNMARRIED }}</option>
                                <option value="{{ STATUS_MARITAL_MARRIED }}">{{ STATUS_MARITAL_MARRIED }}</option>
                            </select>
                            @error('item.status_marital') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_address') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <textarea class="form-control" wire:model="item.address"></textarea>
                            @error('item.address') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_blood_group') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
                            <select class="form-control" wire:model="item.blood_group"">
                                <option value="">- Select -</option>
                                @foreach($blood_groups as $blood_group)
                                    <option value="{{ $blood_group }}">{{ $blood_group }}</option>
                                @endforeach
                            </select>
                            @error('item.blood_group') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label">{{ __('tasks.label_profile_pic') }} <span class="text-danger">*</span></label>
                        <div class="col-sm-7">
<!--                            <form enctype="multipart/form-data" wire:submit.prevent="savePicture">-->
                                <input type="file" class="form-control file-upload" name="picture" wire:model="picture" id="uploadPicture" />
<!--                            </form>-->
                            <p wire:loading wire:target="picture">Uploading...</p>
                            @error('picture') <span class="error text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>

                    @if($picture)
                        <div class="form-group row">
                            <label class="col-sm-5 col-form-label">&nbsp;</label>
                            <div class="col-sm-7">
                                <div class="preview-wrap">
                                    <button type="button" class="close" title="Remove" wire:click="resetUpload()">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <img src="{{ $picture->temporaryUrl() }}" alt="Image not found." />
                                </div>
                            </div>
                        </div>
                    @endif

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" wire:click="saveItem()">{{ __('Save') }}</button>
                    <button type="button" class="btn btn-secondary" wire:click="clearValidationErrors()" data-dismiss="modal">{{ __('Cancel') }}</button>
                </div>
            </form>
        </div>
    </div>
</div>
