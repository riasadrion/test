<x-main-layout>
    <x-slot name="title">{{ __('User Profile') }}</x-slot>

    <x-slot name="breadcrumbs">
        <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">User Profile</li>
        </ol>
    </x-slot>

    <x-slot name="header">
        <div class="card-header">
            <h3 class="card-title">User Profile</h3>
        </div>
    </x-slot>

    <x-slot name="slot">
        <div class="card-body">
            <!-- Styles -->
            <link rel="stylesheet" href="{{ mix('css/app.css') }}">
            <style>.card-body > div > div.mt-5{margin-top:0 !important;}</style>

            @if (Laravel\Fortify\Features::canUpdateProfileInformation())
                @livewire('profile.update-profile-information-form')

                <x-jet-section-border />
            @endif

            @if (Laravel\Fortify\Features::enabled(Laravel\Fortify\Features::updatePasswords()))
                @livewire('profile.update-password-form')

                <x-jet-section-border />
            @endif

            @if (Laravel\Fortify\Features::canManageTwoFactorAuthentication())
                @livewire('profile.two-factor-authentication-form')

                <x-jet-section-border />
            @endif

            <div class="mt-10 sm:mt-0">
                @livewire('profile.logout-other-browser-sessions-form')
            </div>

            @if (Laravel\Jetstream\Jetstream::hasAccountDeletionFeatures())
                <x-jet-section-border />

                @livewire('profile.delete-user-form')
            @endif

            <!-- Scripts -->
            <script src="{{ mix('js/app.js') }}" defer></script>
        </div>
    </x-slot>
</x-main-layout>
