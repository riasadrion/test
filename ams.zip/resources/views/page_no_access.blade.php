<x-slot name="title">
    {{ __('Access Denied') }}
</x-slot>

<x-slot name="header">
    <div class="card-header">
        <h3 class="card-title text-danger">{{ __('You do not have access to this page!') }}</h3>
    </div>
</x-slot>

<div>
    &nbsp;
</div>
