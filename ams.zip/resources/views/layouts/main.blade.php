<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>
        @if (isset($title))
            {{ $title }}
        @endif
        | {{ config('app.name', 'Asset-Management') }}
    </title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Ionicons -->
    <link rel="stylesheet" type="text/css" href="{{ asset('css/custom/ionicons.min.css') }}"/>
    <!-- Theme style -->
    <link rel="stylesheet" type="text/css" href="{{ asset('css/custom/adminlte.min.css') }}"/>
    <!-- Font Awesome -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700"/>

    <link rel="stylesheet" href="{{ asset('css/custom/sweetalert2.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('css/custom/toastr.min.css') }}" />
    <!-- Common style -->
    <link rel="stylesheet" type="text/css" href="{{ asset('css/custom/common.css') }}"/>

    @livewireStyles

    <!-- jQuery -->
    <script type="text/javascript" src="{{ asset('js/custom/jquery.min.js') }}"></script>
    <!-- Bootstrap 4 -->
    <script type="text/javascript" src="{{ asset('js/custom/bootstrap.bundle.min.js') }}"></script>
    <!-- AdminLTE App -->
    <script type="text/javascript" src="{{ asset('js/custom/adminlte.js') }}"></script>
    <!-- Toast & Sweet Alert -->
    <script src="{{ asset('js/custom/sweetalert2.min.js') }}"></script>
    <script src="{{ asset('js/custom/toastr.min.js') }}"></script>
    <!-- Alpine Js -->
    <script src="//unpkg.com/alpinejs" defer></script>
    <!-- Common Js -->
    <script type="text/javascript" src="{{ asset('js/custom/common.js') }}"></script>
</head>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
        </ul>

        <!-- Right navbar links -->
        <ul class="navbar-nav ml-auto">
            <!-- Notifications Dropdown Menu -->
            <li class="nav-item dropdown">
                <a class="nav-link profile-icon" data-toggle="dropdown" href="#">
                    <i class="nav-icon fas fa-th-large"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                    <span class="dropdown-item dropdown-header bg-primary">{{ __('Manage Account') }}</span>
                    <div class="dropdown-divider"></div>
                    <a href="{{ route('profile.show') }}" class="dropdown-item">
                        <i class="fas fa-user mr-2"></i> {{ Auth::user()->name }}
                    </a>
                    <div class="dropdown-divider"></div>
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <a href="javascript:void(0);" class="dropdown-item" onclick="event.preventDefault(); this.closest('form').submit();">
                            <i class="fas fa-sign-out-alt mr-2"></i> {{ __('Log Out') }}
                        </a>
                    </form>
                </div>
            </li>
        </ul>
    </nav>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Brand Logo -->
        <a href="{{ url('/') }}" class="brand-link">
            <img src="{{ asset('img/logo.png') }}" alt="Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
            <span class="brand-text font-weight-light">Asset Management</span>
        </a>
        <!-- Sidebar -->
        <div class="sidebar">
            <!-- Sidebar Menu -->
            @livewire('sidebar-menu')
            <!-- /.sidebar-menu -->
        </div>
        <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-3 col-sm-12">
                        <h4>{{ $title }}</h4>
                    </div>
                    <div class="col-lg-6 col-sm-12" style="position:relative">
                        <div class="alert alert-success alert-dismissible fade hide" id="showAlert" role="alert" style="position:absolute; top:-32px; left:0; z-index:5001; width:100%">
                            <span></span>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-12">&nbsp;</div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="card card-primary card-outline">
                    <!-- Page Heading -->
                    @if (isset($header))
                        {{ $header }}
                    @endif

                    <!-- card-body -->
                    @if (isset($slot))
                        {{ $slot }}
                    @endif
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <!-- /Main content -->
    </div>
    <!-- /.content-wrapper -->

    <footer class="main-footer">
        <div class="float-right d-none d-sm-block">
            <b>Version</b> 1.0
        </div>
        <strong>Copyright &copy; {{ date('Y') }}-{{ (date('Y')+1) }} <a href="http://disbsolution.com/" target="_blank">DISB Solutions Ltd</a>.</strong> All rights
        reserved.
    </footer>

</div>
<!-- ./wrapper -->

@stack('modals')

@livewireScripts

@yield('jsInline')

</body>
</html>
