<?php
return [
    /*--------------------------------------------------------------------------
    | Custom Language Lines for tasks
    |--------------------------------------------------------------------------*/
    // Common
    'label_id' => 'ID',
    'label_name' => 'Name',
    'label_email' => 'Email',
    'label_phone' => 'Phone',
    'label_mobile_no' => 'Mobile No.',
    'label_type' => 'Type',
    'label_controller' => 'Controller',
    'label_ordering' => 'Ordering',
    'label_status' => 'Status',
    'label_action' => 'Action',

    // Module & Task
    'label_task_name_en' => 'Task Name(EN)',
    'label_task_name_bn' => 'Task Name(BN)',
    'label_url' => 'URL/ Path',
    'label_parent' => 'Parent',
    'label_status_notify' => 'Status Notification',

    // User
    'label_username' => 'Username',
    'label_employee_id' => 'Employee ID',
    'label_designation' => 'Designation',
    'label_department' => 'Department',
    'label_dob' => 'Date of Birth',
    'label_gender' => 'Gender',
    'label_status_marital' => 'Marital Status',
    'label_address' => 'Address',
    'label_blood_group' => 'Blood Group',
    'label_profile_pic' => 'Profile Picture',

];
